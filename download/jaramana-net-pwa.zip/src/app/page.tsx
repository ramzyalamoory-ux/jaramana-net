'use client';

import { useState, useEffect, useCallback } from 'react';
import Image from 'next/image';

// PWA Offline Support - IndexedDB Functions
const DB_NAME = 'jaramana-net-db';
const DB_VERSION = 1;

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('subscribers')) db.createObjectStore('subscribers', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('tickets')) db.createObjectStore('tickets', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('debts')) db.createObjectStore('debts', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('settings')) db.createObjectStore('settings', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('pendingSync')) {
        const store = db.createObjectStore('pendingSync', { keyPath: 'id', autoIncrement: true });
        store.createIndex('type', 'type', { unique: false });
      }
    };
  });
}

async function saveToStore(storeName: string, data: any | any[]) {
  try {
    const db = await openDatabase();
    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    const items = Array.isArray(data) ? data : [data];
    items.forEach(item => store.put(item));
    console.log(`[PWA] Saved ${items.length} items to ${storeName}`);
  } catch (e) {
    console.error('[PWA] Save error:', e);
  }
}

async function getAllFromStore<T>(storeName: string): Promise<T[]> {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, 'readonly');
      const store = transaction.objectStore(storeName);
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  } catch (e) {
    console.error('[PWA] Load error:', e);
    return [];
  }
}

// PWA: إضافة عملية للمزامنة لاحقاً
async function addToPendingSync(operation: { type: 'subscriber' | 'ticket' | 'debt'; action: 'create' | 'update' | 'delete'; data: any }) {
  try {
    const db = await openDatabase();
    const transaction = db.transaction('pendingSync', 'readwrite');
    const store = transaction.objectStore('pendingSync');
    store.add({ ...operation, timestamp: new Date().toISOString() });
    console.log('[PWA] Added to pending sync:', operation.action, operation.type);
  } catch (e) {
    console.error('[PWA] Failed to add to pending sync:', e);
  }
}

// PWA: الحصول على عدد العمليات المنتظرة
async function getPendingSyncCount(): Promise<number> {
  try {
    const items = await getAllFromStore<any>('pendingSync');
    return items.length;
  } catch {
    return 0;
  }
}

// PWA: مسح عملية من قائمة الانتظار
async function removePendingSyncItem(id: number) {
  try {
    const db = await openDatabase();
    const transaction = db.transaction('pendingSync', 'readwrite');
    const store = transaction.objectStore('pendingSync');
    store.delete(id);
  } catch (e) {
    console.error('[PWA] Failed to remove pending sync item:', e);
  }
}

// Types
interface Subscriber {
  id: number;
  name: string;
  phone: string;
  address?: string;
  pppoeUser?: string;
  pppoePassword?: string;
  plan?: string;
  monthlyFee?: number;
  balance?: number;
  status?: string;
  paymentStatus?: string;
  lastRenewalDate?: string;
  expiryDate?: string;
  notes?: string;
  createdAt?: string;
}

interface Ticket {
  id: number;
  name: string;
  phone: string;
  subject: string;
  description: string;
  status: string;
  createdAt: string;
}

interface Debt {
  id: number;
  name: string;
  phone?: string;
  address?: string;
  reason?: string;
  amount: number;
  createdAt?: string;
}

interface Settings {
  id?: number;
  adminPassword: string;
  adminPin: string;
  supportName1: string;
  supportPhone1: string;
  supportName2: string;
  supportPhone2: string;
}

// Supabase Config
const SUPABASE_URL = 'https://pypomilurmkzlceecukr.supabase.co';
const SUPABASE_KEY = 'sb_publishable_R30YtCj6dqhLwjTQsrR1Uw_tcItK0JV';

// Available Plans (1MB to 20MB)
const PLANS = [
  { value: '1 ميغا', label: '1 ميغا' },
  { value: '2 ميغا', label: '2 ميغا' },
  { value: '3 ميغا', label: '3 ميغا' },
  { value: '4 ميغا', label: '4 ميغا' },
  { value: '5 ميغا', label: '5 ميغا' },
  { value: '6 ميغا', label: '6 ميغا' },
  { value: '7 ميغا', label: '7 ميغا' },
  { value: '8 ميغا', label: '8 ميغا' },
  { value: '9 ميغا', label: '9 ميغا' },
  { value: '10 ميغا', label: '10 ميغا' },
  { value: '11 ميغا', label: '11 ميغا' },
  { value: '12 ميغا', label: '12 ميغا' },
  { value: '13 ميغا', label: '13 ميغا' },
  { value: '14 ميغا', label: '14 ميغا' },
  { value: '15 ميغا', label: '15 ميغا' },
  { value: '16 ميغا', label: '16 ميغا' },
  { value: '17 ميغا', label: '17 ميغا' },
  { value: '18 ميغا', label: '18 ميغا' },
  { value: '19 ميغا', label: '19 ميغا' },
  { value: '20 ميغا', label: '20 ميغا' },
];

// Payment Status Options
const PAYMENT_STATUS_OPTIONS = [
  { value: 'paid', label: 'دافع', color: 'bg-green-100 text-green-700' },
  { value: 'grace_1day', label: 'مهلة يوم واحد', color: 'bg-yellow-100 text-yellow-700' },
  { value: 'expired', label: 'منتهي الصلاحية', color: 'bg-red-100 text-red-700' },
];

export default function Home() {
  const [darkMode, setDarkMode] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  
  // PWA Offline State
  const [isOnline, setIsOnline] = useState(true);
  const [showInstallPrompt, setShowInstallPrompt] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [pendingSyncCount, setPendingSyncCount] = useState(0);

  // Customer search
  const [searchName, setSearchName] = useState('');
  const [searchResult, setSearchResult] = useState<any>(null);

  // Subscribers
  const [subscribers, setSubscribers] = useState<Subscriber[]>([]);
  const [searchSubscriber, setSearchSubscriber] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterPaymentStatus, setFilterPaymentStatus] = useState('all');
  const [showSubscriberForm, setShowSubscriberForm] = useState(false);
  const [editingSubscriber, setEditingSubscriber] = useState<number | null>(null);
  const [subscriberForm, setSubscriberForm] = useState<Partial<Subscriber>>({ 
    status: 'active', 
    balance: 0, 
    monthlyFee: 0,
    paymentStatus: 'paid'
  });
  const [selectedSubscriberDetails, setSelectedSubscriberDetails] = useState<Subscriber | null>(null);

  // Tickets
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [ticketForm, setTicketForm] = useState({ name: '', phone: '', subject: '', description: '' });
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);

  // Debts
  const [debts, setDebts] = useState<Debt[]>([]);
  const [showDebtForm, setShowDebtForm] = useState(false);
  const [editingDebt, setEditingDebt] = useState<number | null>(null);
  const [debtForm, setDebtForm] = useState<Partial<Debt>>({ amount: 0 });

  // Settings
  const [settings, setSettings] = useState<Settings>({
    adminPassword: '1998',
    adminPin: '1998',
    supportName1: 'Eng. Ramzi',
    supportPhone1: '963959128944',
    supportName2: 'Mr. Gassan',
    supportPhone2: '963998417870'
  });

  // Load theme & session
  useEffect(() => {
    const savedTheme = localStorage.getItem('darkMode');
    if (savedTheme !== null) setDarkMode(savedTheme === 'true');
    const token = localStorage.getItem('adminSession');
    if (token) setIsAdmin(true);
    
    // PWA Online/Offline Detection
    setIsOnline(navigator.onLine);
    const handleOnline = () => { setIsOnline(true); console.log('[PWA] Back online!'); };
    const handleOffline = () => { setIsOnline(false); console.log('[PWA] Gone offline!'); };
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    // PWA Install Prompt
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowInstallPrompt(true);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    
    // تحديث عدد العمليات المنتظرة
    getPendingSyncCount().then(setPendingSyncCount);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
    };
  }, []);

  // PWA: مزامنة تلقائية عند عودة الإنترنت
  useEffect(() => {
    if (isOnline && pendingSyncCount > 0) {
      syncPendingChanges();
    }
  }, [isOnline]);

  // PWA: دالة المزامنة
  const syncPendingChanges = async () => {
    const pendingItems = await getAllFromStore<any>('pendingSync');
    if (pendingItems.length === 0) return;
    
    console.log('[PWA] Syncing', pendingItems.length, 'pending changes...');
    
    for (const item of pendingItems) {
      try {
        if (item.type === 'subscriber') {
          if (item.action === 'create') {
            const res = await fetch(`${SUPABASE_URL}/rest/v1/Subscriber`, {
              method: 'POST',
              headers: getHeaders(),
              body: JSON.stringify(item.data)
            });
            if (res.ok) removePendingSyncItem(item.id);
          } else if (item.action === 'update') {
            const res = await fetch(`${SUPABASE_URL}/rest/v1/Subscriber?id=eq.${item.data.id}`, {
              method: 'PATCH',
              headers: getHeaders(),
              body: JSON.stringify(item.data)
            });
            if (res.ok) removePendingSyncItem(item.id);
          } else if (item.action === 'delete') {
            const res = await fetch(`${SUPABASE_URL}/rest/v1/Subscriber?id=eq.${item.data.id}`, {
              method: 'DELETE',
              headers: getHeaders()
            });
            if (res.ok) removePendingSyncItem(item.id);
          }
        } else if (item.type === 'debt') {
          if (item.action === 'create') {
            const res = await fetch(`${SUPABASE_URL}/rest/v1/Debts`, {
              method: 'POST',
              headers: getHeaders(),
              body: JSON.stringify(item.data)
            });
            if (res.ok) removePendingSyncItem(item.id);
          } else if (item.action === 'update') {
            const res = await fetch(`${SUPABASE_URL}/rest/v1/Debts?id=eq.${item.data.id}`, {
              method: 'PATCH',
              headers: getHeaders(),
              body: JSON.stringify(item.data)
            });
            if (res.ok) removePendingSyncItem(item.id);
          } else if (item.action === 'delete') {
            const res = await fetch(`${SUPABASE_URL}/rest/v1/Debts?id=eq.${item.data.id}`, {
              method: 'DELETE',
              headers: getHeaders()
            });
            if (res.ok) removePendingSyncItem(item.id);
          }
        }
      } catch (e) {
        console.error('[PWA] Failed to sync item:', e);
      }
    }
    
    const newCount = await getPendingSyncCount();
    setPendingSyncCount(newCount);
    
    if (newCount === 0) {
      alert('✅ تمت مزامنة جميع التغييرات!');
      loadSubscribers();
      loadDebts();
    }
  };

  // Load data when admin
  useEffect(() => {
    if (isAdmin) {
      loadSubscribers();
      loadTickets();
      loadDebts();
      loadSettings();
    }
  }, [isAdmin]);

  // API Headers
  const getHeaders = () => ({
    'apikey': SUPABASE_KEY,
    'Authorization': `Bearer ${SUPABASE_KEY}`,
    'Content-Type': 'application/json',
    'Prefer': 'return=representation'
  });

  // Load Subscribers
  const loadSubscribers = async () => {
    try {
      if (navigator.onLine) {
        const res = await fetch(`${SUPABASE_URL}/rest/v1/Subscriber?select=*&order=id.desc`, {
          headers: getHeaders()
        });
        if (!res.ok) throw new Error('Failed to load');
        const data = await res.json();
        setSubscribers(Array.isArray(data) ? data : []);
        // Save to IndexedDB for offline
        saveToStore('subscribers', data);
      } else {
        // Load from IndexedDB
        const offlineData = await getAllFromStore<Subscriber>('subscribers');
        setSubscribers(offlineData);
        console.log('[PWA] Loaded subscribers from offline storage');
      }
    } catch (e) { 
      console.error('Load subscribers error:', e);
      // Try offline data
      const offlineData = await getAllFromStore<Subscriber>('subscribers');
      if (offlineData.length > 0) {
        setSubscribers(offlineData);
      }
    }
  };

  // Load Tickets
  const loadTickets = async () => {
    try {
      if (navigator.onLine) {
        const res = await fetch(`${SUPABASE_URL}/rest/v1/Ticket?select=*&order=id.desc`, {
          headers: getHeaders()
        });
        if (!res.ok) throw new Error('Failed to load');
        const data = await res.json();
        setTickets(Array.isArray(data) ? data : []);
        saveToStore('tickets', data);
      } else {
        const offlineData = await getAllFromStore<Ticket>('tickets');
        setTickets(offlineData);
      }
    } catch (e) { 
      console.error('Load tickets error:', e);
      const offlineData = await getAllFromStore<Ticket>('tickets');
      if (offlineData.length > 0) setTickets(offlineData);
    }
  };

  // Load Debts
  const loadDebts = async () => {
    try {
      if (navigator.onLine) {
        const res = await fetch(`${SUPABASE_URL}/rest/v1/Debts?select=*&order=id.desc`, {
          headers: getHeaders()
        });
        if (!res.ok) throw new Error('Failed to load');
        const data = await res.json();
        setDebts(Array.isArray(data) ? data : []);
        saveToStore('debts', data);
      } else {
        const offlineData = await getAllFromStore<Debt>('debts');
        setDebts(offlineData);
      }
    } catch (e) { 
      console.error('Load debts error:', e);
      const offlineData = await getAllFromStore<Debt>('debts');
      if (offlineData.length > 0) setDebts(offlineData);
    }
  };

  // Load Settings
  const loadSettings = async () => {
    try {
      if (navigator.onLine) {
        const res = await fetch(`${SUPABASE_URL}/rest/v1/Setting?select=*&limit=1`, {
          headers: getHeaders()
        });
        if (!res.ok) throw new Error('Failed to load');
        const data = await res.json();
        if (data && data[0]) {
          setSettings(prev => ({ ...prev, ...data[0] }));
          saveToStore('settings', data[0]);
        }
      } else {
        const offlineData = await getAllFromStore<Settings>('settings');
        if (offlineData.length > 0) setSettings(prev => ({ ...prev, ...offlineData[0] }));
      }
    } catch (e) { 
      console.error('Load settings error:', e);
      const offlineData = await getAllFromStore<Settings>('settings');
      if (offlineData.length > 0) setSettings(prev => ({ ...prev, ...offlineData[0] }));
    }
  };

  // Auth
  const handleLogin = () => {
    if (username === 'admin' && password === settings.adminPassword && pin === settings.adminPin) {
      setIsAdmin(true);
      setLoginOpen(false);
      localStorage.setItem('adminSession', 'valid');
      setUsername(''); 
      setPassword(''); 
      setPin('');
      setError('');
    } else {
      setError('خطأ في تسجيل الدخول');
    }
  };

  const handleLogout = () => {
    setIsAdmin(false);
    localStorage.removeItem('adminSession');
  };

  // Theme
  const toggleTheme = () => {
    setDarkMode(!darkMode);
    localStorage.setItem('darkMode', String(!darkMode));
  };

  // Customer Search
  const handleSearch = async () => {
    if (!searchName.trim()) return;
    setLoading(true);
    try {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/Subscriber?select=*&or=(name.ilike.%25${encodeURIComponent(searchName)}%25,phone.ilike.%25${encodeURIComponent(searchName)}%25)&limit=10`, {
        headers: getHeaders()
      });
      const data = await res.json();
      if (data.length === 1) {
        setSearchResult({ subscriber: data[0], totalDue: data[0].balance || 0 });
      } else if (data.length > 1) {
        setSearchResult({ multipleResults: data, error: `تم العثور على ${data.length} نتائج` });
      } else {
        setSearchResult({ error: 'لا يوجد مشترك بهذا الاسم أو الرقم' });
      }
    } catch (e) {
      setSearchResult({ error: 'خطأ في البحث' });
    }
    setLoading(false);
  };

  // Calculate expiry date
  const calculateExpiryDate = (renewalDate: string) => {
    const date = new Date(renewalDate);
    date.setDate(date.getDate() + 30);
    return date.toISOString();
  };

  // ===== SUBSCRIBERS CRUD =====
  
  // Add/Update Subscriber
  const handleSaveSubscriber = async () => {
    if (!subscriberForm.name || !subscriberForm.phone) {
      setError('الاسم والهاتف مطلوبان');
      return;
    }
    
    setLoading(true);
    setError('');
    
    const now = new Date().toISOString();
    const dataToSave: any = {
      name: subscriberForm.name,
      phone: subscriberForm.phone,
      address: subscriberForm.address || '',
      pppoeUser: subscriberForm.pppoeUser || '',
      pppoePassword: subscriberForm.pppoePassword || '',
      plan: subscriberForm.plan || '',
      monthlyFee: Number(subscriberForm.monthlyFee) || 0,
      balance: Number(subscriberForm.balance) || 0,
      status: subscriberForm.status || 'active',
      paymentStatus: subscriberForm.paymentStatus || 'paid',
      notes: subscriberForm.notes || ''
    };

    // PWA: إذا غير متصل، احفظ محلياً وأضف للمزامنة
    if (!navigator.onLine) {
      if (editingSubscriber) {
        dataToSave.id = editingSubscriber;
        // تحديث محلي
        const updatedSubscribers = subscribers.map(s => s.id === editingSubscriber ? { ...s, ...dataToSave } : s);
        setSubscribers(updatedSubscribers);
        saveToStore('subscribers', updatedSubscribers);
        // إضافة للمزامنة لاحقاً
        await addToPendingSync({ type: 'subscriber', action: 'update', data: dataToSave });
        alert('✅ تم الحفظ محلياً - سيتم المزامنة عند عودة الإنترنت');
      } else {
        // إنشاء ID مؤقت
        const tempId = Date.now();
        dataToSave.id = tempId;
        dataToSave.lastRenewalDate = now;
        dataToSave.expiryDate = calculateExpiryDate(now);
        // إضافة محلياً
        const newSubscribers = [{ ...dataToSave, id: tempId }, ...subscribers];
        setSubscribers(newSubscribers);
        saveToStore('subscribers', newSubscribers);
        // إضافة للمزامنة لاحقاً
        await addToPendingSync({ type: 'subscriber', action: 'create', data: dataToSave });
        alert('✅ تم الحفظ محلياً - سيتم المزامنة عند عودة الإنترنت');
      }
      setPendingSyncCount(await getPendingSyncCount());
      setShowSubscriberForm(false);
      setSubscriberForm({ status: 'active', balance: 0, monthlyFee: 0, paymentStatus: 'paid' });
      setEditingSubscriber(null);
      setLoading(false);
      return;
    }
    
    try {
      if (editingSubscriber) {
        // Update existing
        const res = await fetch(`${SUPABASE_URL}/rest/v1/Subscriber?id=eq.${editingSubscriber}`, {
          method: 'PATCH',
          headers: getHeaders(),
          body: JSON.stringify(dataToSave)
        });
        
        if (!res.ok) {
          const errData = await res.json();
          throw new Error(errData.message || 'فشل التحديث');
        }
        
        alert('✅ تم التحديث بنجاح!');
      } else {
        // Add new
        dataToSave.lastRenewalDate = now;
        dataToSave.expiryDate = calculateExpiryDate(now);
        
        const res = await fetch(`${SUPABASE_URL}/rest/v1/Subscriber`, {
          method: 'POST',
          headers: getHeaders(),
          body: JSON.stringify(dataToSave)
        });
        
        if (!res.ok) {
          const errData = await res.json();
          throw new Error(errData.message || 'فشل الإضافة');
        }
        
        alert('✅ تمت الإضافة بنجاح!');
      }
      
      setShowSubscriberForm(false);
      setSubscriberForm({ status: 'active', balance: 0, monthlyFee: 0, paymentStatus: 'paid' });
      setEditingSubscriber(null);
      await loadSubscribers();
      
    } catch (e: any) {
      console.error('Save subscriber error:', e);
      setError(e.message || 'حدث خطأ');
      alert('❌ ' + (e.message || 'حدث خطأ'));
    }
    
    setLoading(false);
  };

  // Edit Subscriber
  const handleEditSubscriber = (sub: Subscriber) => {
    setSubscriberForm({
      name: sub.name,
      phone: sub.phone,
      address: sub.address || '',
      pppoeUser: sub.pppoeUser || '',
      pppoePassword: sub.pppoePassword || '',
      plan: sub.plan || '',
      monthlyFee: sub.monthlyFee || 0,
      balance: sub.balance || 0,
      status: sub.status || 'active',
      paymentStatus: sub.paymentStatus || 'paid',
      notes: sub.notes || ''
    });
    setEditingSubscriber(sub.id);
    setShowSubscriberForm(true);
  };

  // Delete Subscriber
  const handleDeleteSubscriber = async (id: number) => {
    if (!confirm('هل أنت متأكد من حذف هذا المشترك؟')) return;
    
    // PWA: إذا غير متصل، احذف محلياً وأضف للمزامنة
    if (!navigator.onLine) {
      const updatedSubscribers = subscribers.filter(s => s.id !== id);
      setSubscribers(updatedSubscribers);
      saveToStore('subscribers', updatedSubscribers);
      await addToPendingSync({ type: 'subscriber', action: 'delete', data: { id } });
      setPendingSyncCount(await getPendingSyncCount());
      alert('✅ تم الحذف محلياً - سيتم المزامنة عند عودة الإنترنت');
      return;
    }
    
    setLoading(true);
    try {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/Subscriber?id=eq.${id}`, {
        method: 'DELETE',
        headers: getHeaders()
      });
      
      if (!res.ok) throw new Error('فشل الحذف');
      
      await loadSubscribers();
      alert('✅ تم الحذف بنجاح!');
    } catch (e) {
      console.error('Delete subscriber error:', e);
      alert('❌ حدث خطأ أثناء الحذف');
    }
    setLoading(false);
  };

  // Renew Subscription
  const handleRenewSubscription = async (sub: Subscriber) => {
    const now = new Date().toISOString();
    setLoading(true);
    try {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/Subscriber?id=eq.${sub.id}`, {
        method: 'PATCH',
        headers: getHeaders(),
        body: JSON.stringify({
          paymentStatus: 'paid',
          status: 'active',
          lastRenewalDate: now,
          expiryDate: calculateExpiryDate(now)
        })
      });
      
      if (!res.ok) throw new Error('فشل التجديد');
      
      await loadSubscribers();
      alert('✅ تم تجديد الاشتراك!');
    } catch (e) {
      alert('❌ حدث خطأ');
    }
    setLoading(false);
  };

  // ===== TICKETS CRUD =====
  
  // Add Ticket (Customer)
  const handleAddTicket = async () => {
    if (!ticketForm.subject || !ticketForm.description) {
      setError('الموضوع والتفاصيل مطلوبان');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/Ticket`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ 
          ...ticketForm, 
          status: 'open', 
          createdAt: new Date().toISOString() 
        })
      });
      
      if (!res.ok) throw new Error('فشل الإرسال');
      
      setTicketForm({ name: '', phone: '', subject: '', description: '' });
      alert('✅ تم إرسال الشكوى!');
    } catch (e) {
      setError('حدث خطأ');
    }
    setLoading(false);
  };

  // Update Ticket Status
  const handleUpdateTicketStatus = async (id: number, status: string) => {
    setLoading(true);
    try {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/Ticket?id=eq.${id}`, {
        method: 'PATCH',
        headers: getHeaders(),
        body: JSON.stringify({ status, updatedAt: new Date().toISOString() })
      });
      
      if (!res.ok) throw new Error('فشل التحديث');
      
      await loadTickets();
      setSelectedTicket(null);
      alert('✅ تم تحديث الحالة!');
    } catch (e) {
      alert('❌ حدث خطأ');
    }
    setLoading(false);
  };

  // Delete Ticket
  const handleDeleteTicket = async (id: number) => {
    if (!confirm('هل أنت متأكد من حذف هذه الشكوى؟')) return;
    
    setLoading(true);
    try {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/Ticket?id=eq.${id}`, {
        method: 'DELETE',
        headers: getHeaders()
      });
      
      if (!res.ok) throw new Error('فشل الحذف');
      
      await loadTickets();
      alert('✅ تم الحذف بنجاح!');
    } catch (e) {
      alert('❌ حدث خطأ');
    }
    setLoading(false);
  };

  // ===== DEBTS CRUD =====
  
  // Add/Update Debt
  const handleSaveDebt = async () => {
    if (!debtForm.name || !debtForm.amount) {
      setError('الاسم والمبلغ مطلوبان');
      return;
    }
    
    setLoading(true);
    setError('');
    
    const dataToSave = {
      name: debtForm.name,
      phone: debtForm.phone || '',
      address: debtForm.address || '',
      reason: debtForm.reason || '',
      amount: Number(debtForm.amount) || 0
    };

    // PWA: إذا غير متصل، احفظ محلياً
    if (!navigator.onLine) {
      if (editingDebt) {
        dataToSave.id = editingDebt;
        const updatedDebts = debts.map(d => d.id === editingDebt ? { ...d, ...dataToSave } : d);
        setDebts(updatedDebts);
        saveToStore('debts', updatedDebts);
        await addToPendingSync({ type: 'debt', action: 'update', data: dataToSave });
      } else {
        const tempId = Date.now();
        const newDebt = { ...dataToSave, id: tempId, createdAt: new Date().toISOString() };
        const newDebts = [newDebt, ...debts];
        setDebts(newDebts);
        saveToStore('debts', newDebts);
        await addToPendingSync({ type: 'debt', action: 'create', data: newDebt });
      }
      setPendingSyncCount(await getPendingSyncCount());
      alert('✅ تم الحفظ محلياً - سيتم المزامنة عند عودة الإنترنت');
      setShowDebtForm(false);
      setDebtForm({ amount: 0 });
      setEditingDebt(null);
      setLoading(false);
      return;
    }
    
    try {
      if (editingDebt) {
        // Update
        const res = await fetch(`${SUPABASE_URL}/rest/v1/Debts?id=eq.${editingDebt}`, {
          method: 'PATCH',
          headers: getHeaders(),
          body: JSON.stringify(dataToSave)
        });
        
        if (!res.ok) throw new Error('فشل التحديث');
        
        alert('✅ تم التحديث بنجاح!');
      } else {
        // Add
        const res = await fetch(`${SUPABASE_URL}/rest/v1/Debts`, {
          method: 'POST',
          headers: getHeaders(),
          body: JSON.stringify({ ...dataToSave, createdAt: new Date().toISOString() })
        });
        
        if (!res.ok) throw new Error('فشل الإضافة');
        
        alert('✅ تمت الإضافة بنجاح!');
      }
      
      setShowDebtForm(false);
      setDebtForm({ amount: 0 });
      setEditingDebt(null);
      await loadDebts();
      
    } catch (e: any) {
      setError(e.message || 'حدث خطأ');
      alert('❌ ' + e.message);
    }
    
    setLoading(false);
  };

  // Edit Debt
  const handleEditDebt = (debt: Debt) => {
    setDebtForm({
      name: debt.name,
      phone: debt.phone || '',
      address: debt.address || '',
      reason: debt.reason || '',
      amount: debt.amount
    });
    setEditingDebt(debt.id);
    setShowDebtForm(true);
  };

  // Delete Debt
  const handleDeleteDebt = async (id: number) => {
    if (!confirm('هل أنت متأكد من حذف هذا الدين؟')) return;
    
    // PWA: إذا غير متصل، احذف محلياً
    if (!navigator.onLine) {
      const updatedDebts = debts.filter(d => d.id !== id);
      setDebts(updatedDebts);
      saveToStore('debts', updatedDebts);
      await addToPendingSync({ type: 'debt', action: 'delete', data: { id } });
      setPendingSyncCount(await getPendingSyncCount());
      alert('✅ تم الحذف محلياً - سيتم المزامنة عند عودة الإنترنت');
      return;
    }
    
    setLoading(true);
    try {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/Debts?id=eq.${id}`, {
        method: 'DELETE',
        headers: getHeaders()
      });
      
      if (!res.ok) throw new Error('فشل الحذف');
      
      await loadDebts();
      alert('✅ تم الحذف بنجاح!');
    } catch (e) {
      alert('❌ حدث خطأ');
    }
    setLoading(false);
  };

  // ===== SETTINGS =====
  
  const handleSaveSettings = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/Setting?id=eq.${settings.id || 1}`, {
        method: 'PATCH',
        headers: getHeaders(),
        body: JSON.stringify({
          adminPassword: settings.adminPassword,
          adminPin: settings.adminPin,
          supportName1: settings.supportName1,
          supportPhone1: settings.supportPhone1,
          supportName2: settings.supportName2,
          supportPhone2: settings.supportPhone2
        })
      });
      
      if (!res.ok) throw new Error('فشل الحفظ');
      
      alert('✅ تم حفظ الإعدادات!');
    } catch (e) {
      alert('❌ حدث خطأ');
    }
    setLoading(false);
  };

  // Export CSV
  const handleExportCSV = () => {
    const headers = ['الاسم', 'الهاتف', 'العنوان', 'الباقة', 'الرصيد', 'الفاتورة', 'PPPoE User', 'PPPoE Password', 'حالة الدفع'];
    const rows = subscribers.map(s => [
      s.name, s.phone, s.address || '', s.plan || '', 
      s.balance || 0, s.monthlyFee || 0, 
      s.pppoeUser || '', s.pppoePassword || '', s.paymentStatus || 'paid'
    ]);
    let csv = '\uFEFF' + headers.join(',') + '\n';
    rows.forEach(r => csv += r.map(c => `"${c}"`).join(',') + '\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `مشتركين_${new Date().toLocaleDateString('ar')}.csv`;
    a.click();
  };

  // Export Debts CSV
  const handleExportDebtsCSV = () => {
    const headers = ['الاسم', 'الهاتف', 'العنوان', 'السبب', 'المبلغ'];
    const rows = debts.map(d => [d.name, d.phone || '', d.address || '', d.reason || '', d.amount]);
    let csv = '\uFEFF' + headers.join(',') + '\n';
    rows.forEach(r => csv += r.map(c => `"${c}"`).join(',') + '\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ديون_${new Date().toLocaleDateString('ar')}.csv`;
    a.click();
  };

  // WhatsApp & SMS
  const sendWhatsApp = (phone: string, msg: string) => {
    window.open(`https://wa.me/${phone.replace(/\D/g, '')}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const sendSMS = (phone: string, msg: string) => {
    window.location.href = `sms:${phone.replace(/\D/g, '')}?body=${encodeURIComponent(msg)}`;
  };

  // Print Invoice
  const printInvoice = (sub: Subscriber) => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html dir="rtl">
        <head><title>فاتورة - ${sub.name}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; }
          .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
          .info { margin: 10px 0; }
          .label { font-weight: bold; }
          .footer { margin-top: 30px; text-align: center; font-size: 12px; color: #666; border-top: 1px solid #ccc; padding-top: 10px; }
        </style>
        </head>
        <body>
          <div class="header">
            <h2>Jaramana Net</h2>
            <p>فاتورة اشتراك إنترنت</p>
          </div>
          <div class="info"><span class="label">المشترك:</span> ${sub.name}</div>
          <div class="info"><span class="label">الهاتف:</span> ${sub.phone}</div>
          <div class="info"><span class="label">العنوان:</span> ${sub.address || '-'}</div>
          <div class="info"><span class="label">الباقة:</span> ${sub.plan || '-'}</div>
          <div class="info"><span class="label">حساب PPPoE:</span> ${sub.pppoeUser || '-'}</div>
          <div class="info"><span class="label">كلمة سر PPPoE:</span> ${sub.pppoePassword || '-'}</div>
          <div class="info"><span class="label">قيمة الفاتورة:</span> ${(sub.monthlyFee || 0).toLocaleString()} ل.س</div>
          <div class="info"><span class="label">المبلغ المستحق:</span> <strong style="color: red">${(sub.balance || 0).toLocaleString()} ل.س</strong></div>
          <div class="footer">
            <p>للتواصل: ${settings.supportPhone1}</p>
            <p>تاريخ الطباعة: ${new Date().toLocaleDateString('ar')}</p>
            <p>جميع الحقوق محفوظة © Eng Ramzy Company 2026</p>
          </div>
        </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  // Print Ticket
  const printTicket = (ticket: Ticket) => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html dir="rtl">
        <head><title>شكوى - ${ticket.subject}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; }
          .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
          .info { margin: 10px 0; }
          .label { font-weight: bold; }
          .footer { margin-top: 20px; text-align: center; font-size: 12px; color: #666; }
        </style>
        </head>
        <body>
          <div class="header"><h2>شكوى / اقتراح</h2></div>
          <div class="info"><span class="label">الاسم:</span> ${ticket.name || '-'}</div>
          <div class="info"><span class="label">الهاتف:</span> ${ticket.phone || '-'}</div>
          <div class="info"><span class="label">الموضوع:</span> ${ticket.subject}</div>
          <div class="info"><span class="label">التفاصيل:</span> ${ticket.description}</div>
          <div class="info"><span class="label">الحالة:</span> ${ticket.status === 'open' ? 'مفتوح' : 'مغلق'}</div>
          <div class="info"><span class="label">التاريخ:</span> ${new Date(ticket.createdAt).toLocaleDateString('ar')}</div>
          <div class="footer">جميع الحقوق محفوظة © Eng Ramzy Company 2026</div>
        </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  // Payment Status Badge
  const getPaymentStatusBadge = (status?: string) => {
    const statusOption = PAYMENT_STATUS_OPTIONS.find(s => s.value === status) || PAYMENT_STATUS_OPTIONS[0];
    return (
      <span className={`px-2 py-1 rounded text-xs ${statusOption.color}`}>
        {statusOption.label}
      </span>
    );
  };

  // Filter Subscribers
  const filteredSubscribers = subscribers.filter(s => {
    const matchSearch = !searchSubscriber || s.name?.includes(searchSubscriber) || s.phone?.includes(searchSubscriber);
    const matchStatus = filterStatus === 'all' || s.status === filterStatus;
    const matchPaymentStatus = filterPaymentStatus === 'all' || s.paymentStatus === filterPaymentStatus;
    return matchSearch && matchStatus && matchPaymentStatus;
  });

  // Statistics
  const totalRevenue = subscribers.reduce((sum, s) => sum + (s.monthlyFee || 0), 0);
  const totalBalance = subscribers.reduce((sum, s) => sum + (s.balance || 0), 0);
  const totalDebts = debts.reduce((sum, d) => sum + d.amount, 0);
  const paidCount = subscribers.filter(s => s.paymentStatus === 'paid').length;
  const expiredCount = subscribers.filter(s => s.paymentStatus === 'expired').length;
  const graceCount = subscribers.filter(s => s.paymentStatus === 'grace_1day').length;

  // Classes
  const bgClass = darkMode ? 'bg-[#0f172a]' : 'bg-gray-100';
  const textClass = darkMode ? 'text-white' : 'text-slate-800';
  const cardClass = darkMode ? 'bg-[#1e293b] border border-[#334155]' : 'bg-white shadow';
  const inputClass = darkMode ? 'bg-[#334155] border-[#475569] text-white' : 'bg-white border-gray-300 text-slate-800';

  // PWA Install Handler
  const handleInstallPWA = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      console.log('[PWA] Install outcome:', outcome);
      setDeferredPrompt(null);
      setShowInstallPrompt(false);
    }
  };

  return (
    <div className={`min-h-screen ${bgClass}`} dir="rtl">
      {/* PWA Install Prompt */}
      {showInstallPrompt && (
        <div className="fixed top-0 left-0 right-0 bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-2 px-4 flex items-center justify-between z-50">
          <div className="flex items-center gap-2">
            <span className="text-xl">📱</span>
            <span className="text-sm">ثبّت التطبيق على جهازك للوصول السريع!</span>
          </div>
          <div className="flex gap-2">
            <button onClick={handleInstallPWA} className="bg-white text-indigo-600 px-3 py-1 rounded text-sm font-bold">تثبيت</button>
            <button onClick={() => setShowInstallPrompt(false)} className="text-white/80 hover:text-white text-sm">✕</button>
          </div>
        </div>
      )}
      
      {/* Offline Banner */}
      {!isOnline && (
        <div className="fixed top-0 left-0 right-0 bg-gradient-to-r from-orange-500 to-red-500 text-white py-2 px-4 flex items-center justify-center gap-2 z-50 animate-pulse">
          <span className="text-lg">📡</span>
          <span className="text-sm font-medium">أنت غير متصل بالإنترنت - البيانات من الذاكرة المحلية</span>
        </div>
      )}
      
      {/* Header */}
      <header className={`${darkMode ? 'bg-[#1e3a5f] border-b border-[#334155]' : 'bg-white shadow'} py-3 ${!isOnline || showInstallPrompt ? 'mt-10' : ''}`}>
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-gray-200 relative">
              <Image src="/logo-jaramana.jpg" alt="Logo" fill className="object-cover" priority />
            </div>
            <span className={`text-xl font-bold ${textClass}`}>Jaramana Net</span>
          </div>
          <div className="flex items-center gap-2">
            {/* Connection Status */}
            <div className={`flex items-center gap-1 px-2 py-1 rounded text-xs ${isOnline ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
              <span className={`w-2 h-2 rounded-full ${isOnline ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></span>
              <span>{isOnline ? 'متصل' : 'غير متصل'}</span>
              {pendingSyncCount > 0 && (
                <span className="bg-orange-500 text-white px-1 rounded ml-1">{pendingSyncCount}</span>
              )}
            </div>
            <button onClick={toggleTheme} className={`p-2 rounded-lg ${darkMode ? 'bg-[#334155] text-yellow-400' : 'bg-gray-100'}`}>
              {darkMode ? '☀️' : '🌙'}
            </button>
            {isAdmin ? (
              <button onClick={handleLogout} className="bg-red-500 text-white px-4 py-2 rounded-lg">خروج</button>
            ) : (
              <button onClick={() => setLoginOpen(true)} className="bg-indigo-600 text-white px-4 py-2 rounded-lg">دخول</button>
            )}
          </div>
        </div>
      </header>

      {/* Login Modal */}
      {loginOpen && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <div className={`${darkMode ? 'bg-[#1e293b] border border-[#475569]' : 'bg-white'} p-6 rounded-xl w-80 shadow-2xl`}>
            <h2 className={`text-xl font-bold mb-4 ${textClass}`}>تسجيل الدخول</h2>
            {error && <p className="text-red-400 text-center mb-2 text-sm">{error}</p>}
            <input 
              type="text" 
              placeholder="اسم المستخدم" 
              value={username} 
              onChange={e => setUsername(e.target.value)} 
              className={`w-full border p-3 rounded-lg mb-3 ${inputClass}`} 
            />
            <input 
              type="password" 
              placeholder="كلمة المرور" 
              value={password} 
              onChange={e => setPassword(e.target.value)} 
              className={`w-full border p-3 rounded-lg mb-3 ${inputClass}`} 
            />
            <input 
              type="password" 
              placeholder="PIN" 
              value={pin} 
              onChange={e => setPin(e.target.value.replace(/\D/g, '').slice(0, 4))} 
              className={`w-full border p-3 rounded-lg mb-4 ${inputClass}`} 
              maxLength={4} 
            />
            <div className="flex gap-2">
              <button onClick={handleLogin} className="flex-1 bg-indigo-600 text-white py-3 rounded-lg">دخول</button>
              <button onClick={() => setLoginOpen(false)} className={`px-4 rounded-lg ${darkMode ? 'bg-[#334155] text-white' : 'bg-gray-100'}`}>إلغاء</button>
            </div>
          </div>
        </div>
      )}

      {/* Customer Interface */}
      {!isAdmin && (
        <section className="max-w-xl mx-auto mt-6 px-4">
          {/* Search */}
          <div className={`${cardClass} rounded-xl p-6 mb-6`}>
            <h3 className={`text-lg font-bold mb-4 ${textClass}`}>🔍 البحث عن الفاتورة</h3>
            <p className={`text-sm mb-4 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>أدخل اسمك أو رقم الهاتف</p>
            <div className="flex gap-2 mb-4">
              <input 
                type="text" 
                placeholder="الاسم أو رقم الهاتف" 
                value={searchName} 
                onChange={e => setSearchName(e.target.value)} 
                onKeyDown={e => e.key === 'Enter' && handleSearch()} 
                className={`flex-1 border p-3 rounded-lg ${inputClass}`} 
              />
              <button 
                onClick={handleSearch} 
                disabled={loading} 
                className="bg-indigo-600 text-white px-6 rounded-lg disabled:opacity-50"
              >
                {loading ? '...' : 'بحث'}
              </button>
            </div>
            {searchResult?.subscriber && (
              <div className={`${darkMode ? 'bg-[#334155]' : 'bg-gray-50'} rounded-xl p-4 border ${darkMode ? 'border-[#475569]' : 'border-gray-200'}`}>
                <p className={`font-bold ${textClass}`}>{searchResult.subscriber.name}</p>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{searchResult.subscriber.phone}</p>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>الباقة: {searchResult.subscriber.plan || '-'}</p>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>حساب PPPoE: {searchResult.subscriber.pppoeUser || '-'}</p>
                <div className="mt-2">{getPaymentStatusBadge(searchResult.subscriber.paymentStatus)}</div>
                <p className={`mt-2 font-bold ${searchResult.totalDue > 0 ? 'text-red-400' : 'text-green-400'}`}>
                  {searchResult.totalDue > 0 ? `💵 المبلغ المستحق: ${searchResult.totalDue.toLocaleString()} ل.س` : '✓ لا يوجد رصيد مستحق'}
                </p>
              </div>
            )}
            {searchResult?.error && <p className="text-yellow-400 text-center p-2">{searchResult.error}</p>}
          </div>

          {/* WhatsApp Support */}
          <div className="bg-gradient-to-r from-green-600 to-emerald-700 rounded-xl shadow-lg p-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center text-white text-xl">💬</div>
              <div className="flex-1">
                <p className="font-bold text-white">WhatsApp</p>
                <p className="text-white/90 text-sm">{settings.supportName1}</p>
              </div>
              <a href={`https://wa.me/${settings.supportPhone1}`} target="_blank" className="bg-white text-green-600 px-4 py-2 rounded font-bold text-sm">تواصل</a>
            </div>
          </div>

          {/* Support Numbers */}
          <div className={`${cardClass} rounded-xl p-4 mb-4`}>
            <div className="flex items-center gap-3 mb-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${darkMode ? 'bg-indigo-900' : 'bg-indigo-100'}`}>👤</div>
              <div className="flex-1">
                <p className={`font-medium ${textClass}`}>{settings.supportName1}</p>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{settings.supportPhone1}</p>
              </div>
              <a href={`tel:${settings.supportPhone1}`} className="text-indigo-400 text-sm">اتصال</a>
            </div>
            <div className="flex items-center gap-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${darkMode ? 'bg-indigo-900' : 'bg-indigo-100'}`}>👤</div>
              <div className="flex-1">
                <p className={`font-medium ${textClass}`}>{settings.supportName2}</p>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{settings.supportPhone2}</p>
              </div>
              <a href={`tel:${settings.supportPhone2}`} className="text-indigo-400 text-sm">اتصال</a>
            </div>
          </div>

          {/* Complaint Form */}
          <div className={`${cardClass} rounded-xl p-6 mb-8`}>
            <h3 className={`text-lg font-bold mb-4 ${textClass}`}>📝 إرسال شكوى / اقتراح</h3>
            <div className="space-y-3">
              <input 
                type="text" 
                placeholder="الاسم" 
                value={ticketForm.name} 
                onChange={e => setTicketForm({ ...ticketForm, name: e.target.value })} 
                className={`w-full border p-3 rounded-lg ${inputClass}`} 
              />
              <input 
                type="text" 
                placeholder="رقم الهاتف" 
                value={ticketForm.phone} 
                onChange={e => setTicketForm({ ...ticketForm, phone: e.target.value })} 
                className={`w-full border p-3 rounded-lg ${inputClass}`} 
              />
              <input 
                type="text" 
                placeholder="الموضوع" 
                value={ticketForm.subject} 
                onChange={e => setTicketForm({ ...ticketForm, subject: e.target.value })} 
                className={`w-full border p-3 rounded-lg ${inputClass}`} 
              />
              <textarea 
                placeholder="تفاصيل الشكوى أو الاقتراح" 
                value={ticketForm.description} 
                onChange={e => setTicketForm({ ...ticketForm, description: e.target.value })} 
                className={`w-full border p-3 rounded-lg h-24 ${inputClass}`} 
              />
              <button 
                onClick={handleAddTicket} 
                disabled={loading} 
                className="w-full bg-indigo-600 text-white py-3 rounded-lg disabled:opacity-50"
              >
                {loading ? '...' : 'إرسال الشكوى'}
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Admin Dashboard */}
      {isAdmin && (
        <section className="max-w-7xl mx-auto mt-4 px-4 pb-8">
          {/* Tabs */}
          <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
            {[
              { id: 'dashboard', label: 'الرئيسية', icon: '🏠' },
              { id: 'subscribers', label: 'المشتركين', icon: '👥' },
              { id: 'debts', label: 'الديون', icon: '💰' },
              { id: 'tickets', label: 'الشكاوى', icon: '🎫' },
              { id: 'settings', label: 'الإعدادات', icon: '⚙️' },
            ].map(tab => (
              <button 
                key={tab.id} 
                onClick={() => setActiveTab(tab.id)} 
                className={`flex items-center gap-2 px-4 py-2 rounded-lg whitespace-nowrap ${activeTab === tab.id ? 'bg-indigo-600 text-white' : darkMode ? 'bg-[#334155] text-white' : 'bg-gray-100 text-slate-600'}`}
              >
                <span>{tab.icon}</span><span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Dashboard Tab */}
          {activeTab === 'dashboard' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className={`${cardClass} rounded-xl p-6`}>
                  <p className="text-3xl mb-2">👥</p>
                  <p className={`text-2xl font-bold ${textClass}`}>{subscribers.length}</p>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>مشتركين</p>
                </div>
                <div className={`${darkMode ? 'bg-green-900/30 border-green-800' : 'bg-green-50 border-green-200'} rounded-xl p-6 border`}>
                  <p className="text-3xl mb-2">✅</p>
                  <p className={`text-2xl font-bold ${darkMode ? 'text-green-400' : 'text-green-600'}`}>{paidCount}</p>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>دافعين</p>
                </div>
                <div className={`${darkMode ? 'bg-yellow-900/30 border-yellow-800' : 'bg-yellow-50 border-yellow-200'} rounded-xl p-6 border`}>
                  <p className="text-3xl mb-2">⏰</p>
                  <p className={`text-2xl font-bold ${darkMode ? 'text-yellow-400' : 'text-yellow-600'}`}>{graceCount}</p>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>مهلة يوم</p>
                </div>
                <div className={`${darkMode ? 'bg-red-900/30 border-red-800' : 'bg-red-50 border-red-200'} rounded-xl p-6 border`}>
                  <p className="text-3xl mb-2">🚫</p>
                  <p className={`text-2xl font-bold ${darkMode ? 'text-red-400' : 'text-red-600'}`}>{expiredCount}</p>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>منتهي</p>
                </div>
              </div>
              
              <div className="grid md:grid-cols-3 gap-4">
                <div className={`${cardClass} rounded-xl p-6`}>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>إجمالي الفواتير الشهرية</p>
                  <p className="text-2xl font-bold text-green-500">{totalRevenue.toLocaleString()} ل.س</p>
                </div>
                <div className={`${cardClass} rounded-xl p-6`}>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>إجمالي المديونية</p>
                  <p className="text-2xl font-bold text-red-500">{totalBalance.toLocaleString()} ل.س</p>
                </div>
                <div className={`${cardClass} rounded-xl p-6`}>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>إجمالي الاستدانات</p>
                  <p className="text-2xl font-bold text-orange-500">{totalDebts.toLocaleString()} ل.س</p>
                </div>
              </div>

              {/* Recent Open Tickets */}
              <div className={`${cardClass} rounded-xl p-6`}>
                <h3 className={`text-lg font-bold mb-4 ${textClass}`}>🎫 الشكاوى المفتوحة ({tickets.filter(t => t.status === 'open').length})</h3>
                <div className="space-y-2">
                  {tickets.filter(t => t.status === 'open').slice(0, 5).map(ticket => (
                    <div key={ticket.id} className={`p-3 rounded-lg ${darkMode ? 'bg-[#334155]' : 'bg-gray-50'} flex justify-between items-center`}>
                      <div>
                        <p className={`font-medium ${textClass}`}>{ticket.subject}</p>
                        <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{ticket.name} - {ticket.phone}</p>
                      </div>
                      <button onClick={() => setSelectedTicket(ticket)} className="text-indigo-400 text-sm">عرض</button>
                    </div>
                  ))}
                  {tickets.filter(t => t.status === 'open').length === 0 && (
                    <p className={`text-center ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>لا توجد شكاوى مفتوحة</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Subscribers Tab */}
          {activeTab === 'subscribers' && (
            <div className="space-y-4">
              {/* Toolbar */}
              <div className={`${cardClass} rounded-xl p-4`}>
                <div className="flex flex-wrap gap-3 justify-between items-center">
                  <div className="flex gap-2 flex-1 min-w-0">
                    <input 
                      type="text" 
                      placeholder="بحث..." 
                      value={searchSubscriber} 
                      onChange={e => setSearchSubscriber(e.target.value)} 
                      className={`border p-2 rounded-lg flex-1 min-w-32 ${inputClass}`} 
                    />
                    <select 
                      value={filterStatus} 
                      onChange={e => setFilterStatus(e.target.value)} 
                      className={`border p-2 rounded-lg ${inputClass}`}
                    >
                      <option value="all">الكل</option>
                      <option value="active">نشط</option>
                      <option value="suspended">موقوف</option>
                    </select>
                    <select 
                      value={filterPaymentStatus} 
                      onChange={e => setFilterPaymentStatus(e.target.value)} 
                      className={`border p-2 rounded-lg ${inputClass}`}
                    >
                      <option value="all">كل الحالات</option>
                      <option value="paid">دافع</option>
                      <option value="grace_1day">مهلة يوم</option>
                      <option value="expired">منتهي</option>
                    </select>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    <button onClick={handleExportCSV} className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm">📥 تصدير</button>
                    <button 
                      onClick={() => { 
                        setShowSubscriberForm(true); 
                        setEditingSubscriber(null); 
                        setSubscriberForm({ status: 'active', balance: 0, monthlyFee: 0, paymentStatus: 'paid' }); 
                      }} 
                      className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm"
                    >
                      + إضافة
                    </button>
                  </div>
                </div>
              </div>

              {/* Subscriber Form */}
              {showSubscriberForm && (
                <div className={`${cardClass} rounded-xl p-6`}>
                  <h3 className={`text-lg font-bold mb-4 ${textClass}`}>
                    {editingSubscriber ? 'تعديل' : 'إضافة'} مشترك
                  </h3>
                  <div className="grid md:grid-cols-3 gap-3">
                    <input 
                      type="text" 
                      placeholder="الاسم الثلاثي *" 
                      value={subscriberForm.name || ''} 
                      onChange={e => setSubscriberForm({ ...subscriberForm, name: e.target.value })} 
                      className={`border p-2 rounded-lg ${inputClass}`} 
                    />
                    <input 
                      type="text" 
                      placeholder="الهاتف *" 
                      value={subscriberForm.phone || ''} 
                      onChange={e => setSubscriberForm({ ...subscriberForm, phone: e.target.value })} 
                      className={`border p-2 rounded-lg ${inputClass}`} 
                    />
                    <input 
                      type="text" 
                      placeholder="العنوان" 
                      value={subscriberForm.address || ''} 
                      onChange={e => setSubscriberForm({ ...subscriberForm, address: e.target.value })} 
                      className={`border p-2 rounded-lg ${inputClass}`} 
                    />
                    
                    <select 
                      value={subscriberForm.plan || ''} 
                      onChange={e => setSubscriberForm({ ...subscriberForm, plan: e.target.value })} 
                      className={`border p-2 rounded-lg ${inputClass}`}
                    >
                      <option value="">اختر الباقة</option>
                      {PLANS.map(p => (
                        <option key={p.value} value={p.value}>{p.label}</option>
                      ))}
                    </select>
                    
                    <input 
                      type="number" 
                      placeholder="قيمة الفاتورة (ل.س)" 
                      value={subscriberForm.monthlyFee || 0} 
                      onChange={e => setSubscriberForm({ ...subscriberForm, monthlyFee: Number(e.target.value) })} 
                      className={`border p-2 rounded-lg ${inputClass}`} 
                    />
                    <input 
                      type="number" 
                      placeholder="المبلغ المستحق (ل.س)" 
                      value={subscriberForm.balance || 0} 
                      onChange={e => setSubscriberForm({ ...subscriberForm, balance: Number(e.target.value) })} 
                      className={`border p-2 rounded-lg ${inputClass}`} 
                    />
                    
                    <input 
                      type="text" 
                      placeholder="اسم مستخدم PPPoE" 
                      value={subscriberForm.pppoeUser || ''} 
                      onChange={e => setSubscriberForm({ ...subscriberForm, pppoeUser: e.target.value })} 
                      className={`border p-2 rounded-lg ${inputClass}`} 
                    />
                    <input 
                      type="text" 
                      placeholder="كلمة سر PPPoE" 
                      value={subscriberForm.pppoePassword || ''} 
                      onChange={e => setSubscriberForm({ ...subscriberForm, pppoePassword: e.target.value })} 
                      className={`border p-2 rounded-lg ${inputClass}`} 
                    />
                    
                    <select 
                      value={subscriberForm.paymentStatus || 'paid'} 
                      onChange={e => setSubscriberForm({ ...subscriberForm, paymentStatus: e.target.value })} 
                      className={`border p-2 rounded-lg ${inputClass}`}
                    >
                      {PAYMENT_STATUS_OPTIONS.map(opt => (
                        <option key={opt.value} value={opt.value}>{opt.label}</option>
                      ))}
                    </select>
                    
                    <select 
                      value={subscriberForm.status || 'active'} 
                      onChange={e => setSubscriberForm({ ...subscriberForm, status: e.target.value })} 
                      className={`border p-2 rounded-lg ${inputClass}`}
                    >
                      <option value="active">نشط</option>
                      <option value="suspended">موقوف</option>
                    </select>
                    
                    <textarea 
                      placeholder="ملاحظات" 
                      value={subscriberForm.notes || ''} 
                      onChange={e => setSubscriberForm({ ...subscriberForm, notes: e.target.value })} 
                      className={`border p-2 rounded-lg md:col-span-3 ${inputClass}`} 
                    />
                  </div>
                  <div className="flex gap-2 mt-4">
                    <button 
                      onClick={handleSaveSubscriber} 
                      disabled={loading} 
                      className="bg-indigo-600 text-white px-4 py-2 rounded-lg disabled:opacity-50"
                    >
                      {loading ? '...' : (editingSubscriber ? 'تحديث' : 'إضافة')}
                    </button>
                    <button 
                      onClick={() => { setShowSubscriberForm(false); setEditingSubscriber(null); }} 
                      className={`px-4 py-2 rounded-lg ${darkMode ? 'bg-[#334155] text-white' : 'bg-gray-100'}`}
                    >
                      إلغاء
                    </button>
                  </div>
                </div>
              )}

              {/* Subscribers Table */}
              <div className={`${cardClass} rounded-xl overflow-hidden`}>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className={darkMode ? 'bg-[#334155]' : 'bg-gray-50'}>
                      <tr>
                        <th className={`text-right p-3 ${textClass}`}>الاسم</th>
                        <th className={`text-right p-3 ${textClass}`}>الهاتف</th>
                        <th className={`text-right p-3 ${textClass}`}>الباقة</th>
                        <th className={`text-right p-3 ${textClass}`}>PPPoE</th>
                        <th className={`text-right p-3 ${textClass}`}>المستحق</th>
                        <th className={`text-right p-3 ${textClass}`}>الحالة</th>
                        <th className={`text-right p-3 ${textClass}`}>إجراءات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredSubscribers.map(sub => (
                        <tr key={sub.id} className={`border-b ${darkMode ? 'border-[#334155]' : 'border-gray-100'}`}>
                          <td className={`p-3 ${textClass}`}>
                            <div className="font-medium">{sub.name}</div>
                            <div className="text-xs text-gray-400">{sub.address || '-'}</div>
                          </td>
                          <td className={`p-3 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{sub.phone}</td>
                          <td className={`p-3 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{sub.plan || '-'}</td>
                          <td className={`p-3 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                            <div className="text-xs">
                              <div>U: {sub.pppoeUser || '-'}</div>
                              <div>P: {sub.pppoePassword || '-'}</div>
                            </div>
                          </td>
                          <td className={`p-3 font-bold ${(sub.balance || 0) > 0 ? 'text-red-500' : 'text-green-500'}`}>
                            {(sub.balance || 0).toLocaleString()} ل.س
                          </td>
                          <td className="p-3">{getPaymentStatusBadge(sub.paymentStatus)}</td>
                          <td className="p-3">
                            <div className="flex gap-1 flex-wrap">
                              <button onClick={() => setSelectedSubscriberDetails(sub)} className="text-sm bg-gray-50 text-gray-600 px-2 py-1 rounded" title="عرض">👁️</button>
                              {sub.paymentStatus === 'expired' && (
                                <button onClick={() => handleRenewSubscription(sub)} className="text-sm bg-green-50 text-green-600 px-2 py-1 rounded" title="تجديد">🔄</button>
                              )}
                              <button onClick={() => sendWhatsApp(sub.phone || '', `مرحباً ${sub.name}`)} className="text-sm bg-green-50 text-green-600 px-2 py-1 rounded" title="واتساب">💬</button>
                              <button onClick={() => printInvoice(sub)} className="text-sm bg-purple-50 text-purple-600 px-2 py-1 rounded" title="طباعة">🖨️</button>
                              <button onClick={() => handleEditSubscriber(sub)} className="text-sm bg-yellow-50 text-yellow-600 px-2 py-1 rounded" title="تعديل">✏️</button>
                              <button onClick={() => handleDeleteSubscriber(sub.id)} className="text-sm bg-red-50 text-red-600 px-2 py-1 rounded" title="حذف">🗑️</button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Subscriber Details Modal */}
          {selectedSubscriberDetails && (
            <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
              <div className={`${darkMode ? 'bg-[#1e293b] border border-[#475569]' : 'bg-white'} rounded-xl w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto`}>
                <div className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h2 className={`text-xl font-bold ${textClass}`}>تفاصيل المشترك</h2>
                    <button onClick={() => setSelectedSubscriberDetails(null)} className="text-gray-400 hover:text-gray-600 text-2xl">✕</button>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between border-b pb-2">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>الاسم:</span>
                      <span className={`font-bold ${textClass}`}>{selectedSubscriberDetails.name}</span>
                    </div>
                    <div className="flex justify-between border-b pb-2">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>الهاتف:</span>
                      <span className={textClass}>{selectedSubscriberDetails.phone}</span>
                    </div>
                    <div className="flex justify-between border-b pb-2">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>العنوان:</span>
                      <span className={textClass}>{selectedSubscriberDetails.address || '-'}</span>
                    </div>
                    <div className="flex justify-between border-b pb-2">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>الباقة:</span>
                      <span className={textClass}>{selectedSubscriberDetails.plan || '-'}</span>
                    </div>
                    <div className="flex justify-between border-b pb-2">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>قيمة الفاتورة:</span>
                      <span className={textClass}>{(selectedSubscriberDetails.monthlyFee || 0).toLocaleString()} ل.س</span>
                    </div>
                    <div className="flex justify-between border-b pb-2">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>المبلغ المستحق:</span>
                      <span className={`font-bold ${(selectedSubscriberDetails.balance || 0) > 0 ? 'text-red-500' : 'text-green-500'}`}>
                        {(selectedSubscriberDetails.balance || 0).toLocaleString()} ل.س
                      </span>
                    </div>
                    <div className="flex justify-between border-b pb-2">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>حساب PPPoE:</span>
                      <span className={`font-mono ${textClass}`}>{selectedSubscriberDetails.pppoeUser || '-'}</span>
                    </div>
                    <div className="flex justify-between border-b pb-2">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>كلمة سر PPPoE:</span>
                      <span className={`font-mono ${textClass}`}>{selectedSubscriberDetails.pppoePassword || '-'}</span>
                    </div>
                    <div className="flex justify-between border-b pb-2">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>حالة الدفع:</span>
                      {getPaymentStatusBadge(selectedSubscriberDetails.paymentStatus)}
                    </div>
                    <div className="flex justify-between border-b pb-2">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>ملاحظات:</span>
                      <span className={textClass}>{selectedSubscriberDetails.notes || '-'}</span>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <button onClick={() => handleRenewSubscription(selectedSubscriberDetails)} className="flex-1 bg-green-600 text-white py-2 rounded-lg">🔄 تجديد</button>
                    <button onClick={() => { handleEditSubscriber(selectedSubscriberDetails); setSelectedSubscriberDetails(null); }} className={`flex-1 py-2 rounded-lg ${darkMode ? 'bg-[#334155] text-white' : 'bg-gray-100'}`}>✏️ تعديل</button>
                    <button onClick={() => printInvoice(selectedSubscriberDetails)} className="flex-1 bg-indigo-600 text-white py-2 rounded-lg">🖨️ طباعة</button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Debts Tab */}
          {activeTab === 'debts' && (
            <div className="space-y-4">
              <div className={`${cardClass} rounded-xl p-4`}>
                <div className="flex justify-between items-center">
                  <h3 className={`text-lg font-bold ${textClass}`}>💰 إدارة الديون</h3>
                  <div className="flex gap-2">
                    <button onClick={handleExportDebtsCSV} className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm">📥 تصدير</button>
                    <button onClick={() => { setShowDebtForm(true); setEditingDebt(null); setDebtForm({ amount: 0 }); }} className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm">+ إضافة</button>
                  </div>
                </div>
              </div>

              {/* Debt Form */}
              {showDebtForm && (
                <div className={`${cardClass} rounded-xl p-6`}>
                  <h3 className={`text-lg font-bold mb-4 ${textClass}`}>{editingDebt ? 'تعديل' : 'إضافة'} دين</h3>
                  <div className="grid md:grid-cols-2 gap-3">
                    <input 
                      type="text" 
                      placeholder="الاسم *" 
                      value={debtForm.name || ''} 
                      onChange={e => setDebtForm({ ...debtForm, name: e.target.value })} 
                      className={`border p-2 rounded-lg ${inputClass}`} 
                    />
                    <input 
                      type="text" 
                      placeholder="الهاتف" 
                      value={debtForm.phone || ''} 
                      onChange={e => setDebtForm({ ...debtForm, phone: e.target.value })} 
                      className={`border p-2 rounded-lg ${inputClass}`} 
                    />
                    <input 
                      type="text" 
                      placeholder="العنوان" 
                      value={debtForm.address || ''} 
                      onChange={e => setDebtForm({ ...debtForm, address: e.target.value })} 
                      className={`border p-2 rounded-lg ${inputClass}`} 
                    />
                    <input 
                      type="number" 
                      placeholder="المبلغ (ل.س) *" 
                      value={debtForm.amount || 0} 
                      onChange={e => setDebtForm({ ...debtForm, amount: Number(e.target.value) })} 
                      className={`border p-2 rounded-lg ${inputClass}`} 
                    />
                    <textarea 
                      placeholder="سبب الاستدانة" 
                      value={debtForm.reason || ''} 
                      onChange={e => setDebtForm({ ...debtForm, reason: e.target.value })} 
                      className={`border p-2 rounded-lg md:col-span-2 ${inputClass}`} 
                    />
                  </div>
                  <div className="flex gap-2 mt-4">
                    <button onClick={handleSaveDebt} disabled={loading} className="bg-indigo-600 text-white px-4 py-2 rounded-lg disabled:opacity-50">
                      {loading ? '...' : (editingDebt ? 'تحديث' : 'إضافة')}
                    </button>
                    <button onClick={() => { setShowDebtForm(false); setEditingDebt(null); }} className={`px-4 py-2 rounded-lg ${darkMode ? 'bg-[#334155] text-white' : 'bg-gray-100'}`}>إلغاء</button>
                  </div>
                </div>
              )}

              {/* Debts Table */}
              <div className={`${cardClass} rounded-xl overflow-hidden`}>
                <table className="w-full">
                  <thead className={darkMode ? 'bg-[#334155]' : 'bg-gray-50'}>
                    <tr>
                      <th className={`text-right p-3 ${textClass}`}>الاسم</th>
                      <th className={`text-right p-3 ${textClass}`}>الهاتف</th>
                      <th className={`text-right p-3 ${textClass}`}>العنوان</th>
                      <th className={`text-right p-3 ${textClass}`}>السبب</th>
                      <th className={`text-right p-3 ${textClass}`}>المبلغ</th>
                      <th className={`text-right p-3 ${textClass}`}>إجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {debts.map(debt => (
                      <tr key={debt.id} className={`border-b ${darkMode ? 'border-[#334155]' : 'border-gray-100'}`}>
                        <td className={`p-3 ${textClass}`}>{debt.name}</td>
                        <td className={`p-3 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{debt.phone || '-'}</td>
                        <td className={`p-3 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{debt.address || '-'}</td>
                        <td className={`p-3 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{debt.reason || '-'}</td>
                        <td className={`p-3 font-bold text-red-500`}>{debt.amount.toLocaleString()} ل.س</td>
                        <td className="p-3">
                          <div className="flex gap-1">
                            <button onClick={() => handleEditDebt(debt)} className="text-sm bg-yellow-50 text-yellow-600 px-2 py-1 rounded">✏️</button>
                            <button onClick={() => sendWhatsApp(debt.phone || '', `مرحباً ${debt.name}`)} className="text-sm bg-green-50 text-green-600 px-2 py-1 rounded">💬</button>
                            <button onClick={() => handleDeleteDebt(debt.id)} className="text-sm bg-red-50 text-red-600 px-2 py-1 rounded">🗑️</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Tickets Tab */}
          {activeTab === 'tickets' && (
            <div className="space-y-4">
              <div className={`${cardClass} rounded-xl p-4`}>
                <h3 className={`text-lg font-bold ${textClass}`}>🎫 إدارة الشكاوى</h3>
              </div>

              <div className={`${cardClass} rounded-xl overflow-hidden`}>
                <table className="w-full">
                  <thead className={darkMode ? 'bg-[#334155]' : 'bg-gray-50'}>
                    <tr>
                      <th className={`text-right p-3 ${textClass}`}>الاسم</th>
                      <th className={`text-right p-3 ${textClass}`}>الهاتف</th>
                      <th className={`text-right p-3 ${textClass}`}>الموضوع</th>
                      <th className={`text-right p-3 ${textClass}`}>الحالة</th>
                      <th className={`text-right p-3 ${textClass}`}>التاريخ</th>
                      <th className={`text-right p-3 ${textClass}`}>إجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tickets.map(ticket => (
                      <tr key={ticket.id} className={`border-b ${darkMode ? 'border-[#334155]' : 'border-gray-100'}`}>
                        <td className={`p-3 ${textClass}`}>{ticket.name || '-'}</td>
                        <td className={`p-3 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{ticket.phone || '-'}</td>
                        <td className={`p-3 ${textClass}`}>{ticket.subject}</td>
                        <td className="p-3">
                          <span className={`px-2 py-1 rounded text-xs ${ticket.status === 'open' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'}`}>
                            {ticket.status === 'open' ? 'مفتوح' : 'مغلق'}
                          </span>
                        </td>
                        <td className={`p-3 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          {new Date(ticket.createdAt).toLocaleDateString('ar')}
                        </td>
                        <td className="p-3">
                          <div className="flex gap-1">
                            <button onClick={() => setSelectedTicket(ticket)} className="text-sm bg-gray-50 text-gray-600 px-2 py-1 rounded">👁️</button>
                            <button onClick={() => printTicket(ticket)} className="text-sm bg-purple-50 text-purple-600 px-2 py-1 rounded">🖨️</button>
                            <button onClick={() => handleDeleteTicket(ticket.id)} className="text-sm bg-red-50 text-red-600 px-2 py-1 rounded">🗑️</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Ticket Details Modal */}
          {selectedTicket && (
            <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
              <div className={`${darkMode ? 'bg-[#1e293b] border border-[#475569]' : 'bg-white'} rounded-xl w-full max-w-lg shadow-2xl`}>
                <div className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h2 className={`text-xl font-bold ${textClass}`}>تفاصيل الشكوى</h2>
                    <button onClick={() => setSelectedTicket(null)} className="text-gray-400 hover:text-gray-600 text-2xl">✕</button>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between border-b pb-2">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>الاسم:</span>
                      <span className={textClass}>{selectedTicket.name || '-'}</span>
                    </div>
                    <div className="flex justify-between border-b pb-2">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>الهاتف:</span>
                      <span className={textClass}>{selectedTicket.phone || '-'}</span>
                    </div>
                    <div className="flex justify-between border-b pb-2">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>الموضوع:</span>
                      <span className={`font-bold ${textClass}`}>{selectedTicket.subject}</span>
                    </div>
                    <div className="border-b pb-2">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>التفاصيل:</span>
                      <p className={`mt-2 ${textClass}`}>{selectedTicket.description}</p>
                    </div>
                    <div className="flex justify-between border-b pb-2">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>الحالة:</span>
                      <span className={`px-2 py-1 rounded text-xs ${selectedTicket.status === 'open' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'}`}>
                        {selectedTicket.status === 'open' ? 'مفتوح' : 'مغلق'}
                      </span>
                    </div>
                    <div className="flex justify-between border-b pb-2">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>التاريخ:</span>
                      <span className={textClass}>{new Date(selectedTicket.createdAt).toLocaleDateString('ar')}</span>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    {selectedTicket.status === 'open' && (
                      <button onClick={() => handleUpdateTicketStatus(selectedTicket.id, 'closed')} className="flex-1 bg-green-600 text-white py-2 rounded-lg">✓ إغلاق</button>
                    )}
                    <button onClick={() => selectedTicket.phone && sendWhatsApp(selectedTicket.phone, 'شكراً لتواصلك مع Jaramana Net')} className={`flex-1 py-2 rounded-lg ${darkMode ? 'bg-[#334155] text-white' : 'bg-gray-100'}`}>💬 واتساب</button>
                    <button onClick={() => printTicket(selectedTicket)} className="flex-1 bg-indigo-600 text-white py-2 rounded-lg">🖨️ طباعة</button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Settings Tab */}
          {activeTab === 'settings' && (
            <div className="space-y-4">
              <div className={`${cardClass} rounded-xl p-6`}>
                <h3 className={`text-lg font-bold mb-4 ${textClass}`}>⚙️ الإعدادات</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className={`block text-sm mb-1 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>كلمة مرور الأدمن</label>
                    <input 
                      type="text" 
                      value={settings.adminPassword} 
                      onChange={e => setSettings({ ...settings, adminPassword: e.target.value })} 
                      className={`w-full border p-2 rounded-lg ${inputClass}`} 
                    />
                  </div>
                  <div>
                    <label className={`block text-sm mb-1 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>PIN</label>
                    <input 
                      type="text" 
                      value={settings.adminPin} 
                      onChange={e => setSettings({ ...settings, adminPin: e.target.value })} 
                      className={`w-full border p-2 rounded-lg ${inputClass}`} 
                      maxLength={4} 
                    />
                  </div>
                  <div>
                    <label className={`block text-sm mb-1 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>اسم الدعم 1</label>
                    <input 
                      type="text" 
                      value={settings.supportName1} 
                      onChange={e => setSettings({ ...settings, supportName1: e.target.value })} 
                      className={`w-full border p-2 rounded-lg ${inputClass}`} 
                    />
                  </div>
                  <div>
                    <label className={`block text-sm mb-1 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>رقم الدعم 1</label>
                    <input 
                      type="text" 
                      value={settings.supportPhone1} 
                      onChange={e => setSettings({ ...settings, supportPhone1: e.target.value })} 
                      className={`w-full border p-2 rounded-lg ${inputClass}`} 
                    />
                  </div>
                  <div>
                    <label className={`block text-sm mb-1 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>اسم الدعم 2</label>
                    <input 
                      type="text" 
                      value={settings.supportName2} 
                      onChange={e => setSettings({ ...settings, supportName2: e.target.value })} 
                      className={`w-full border p-2 rounded-lg ${inputClass}`} 
                    />
                  </div>
                  <div>
                    <label className={`block text-sm mb-1 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>رقم الدعم 2</label>
                    <input 
                      type="text" 
                      value={settings.supportPhone2} 
                      onChange={e => setSettings({ ...settings, supportPhone2: e.target.value })} 
                      className={`w-full border p-2 rounded-lg ${inputClass}`} 
                    />
                  </div>
                </div>
                <button 
                  onClick={handleSaveSettings}
                  className="mt-4 bg-indigo-600 text-white px-6 py-2 rounded-lg"
                >
                  💾 حفظ الإعدادات
                </button>
              </div>
            </div>
          )}
        </section>
      )}

      {/* Footer */}
      <footer className={`${darkMode ? 'bg-[#1e293b] border-t border-[#334155]' : 'bg-white shadow'} py-4 mt-8`}>
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
            جميع الحقوق محفوظة © Eng Ramzy Company 2026
          </p>
        </div>
      </footer>
    </div>
  );
}
