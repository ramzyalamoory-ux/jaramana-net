'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Search,
  UserPlus,
  FileText,
  Users,
  LogOut,
  LogIn,
  Trash2,
  Edit,
  Plus,
  CheckCircle,
  XCircle,
  Loader2,
  Phone,
  Shield,
  Wifi,
  Package,
  ArrowDownCircle,
  ArrowUpCircle,
  Settings,
  Save,
  AlertTriangle,
  Box,
  Layers,
} from 'lucide-react';
import Image from 'next/image';

// Types
interface Invoice {
  id: number;
  subscriberId: number;
  month: string;
  amount: number;
  isPaid: boolean;
  dueDate: string;
  paidAt: string | null;
  notes: string | null;
  createdAt: string;
  subscriber?: Subscriber;
}

interface Subscriber {
  id: number;
  name: string;
  phone: string;
  address: string | null;
  monthlyFee: number;
  isActive: boolean;
  createdAt: string;
  invoices?: Invoice[];
}

interface SearchResult {
  subscriber: Subscriber;
  totalDue: number;
}

interface ProductCategory {
  id: number;
  name: string;
  nameEn: string | null;
  description: string | null;
  _count?: { products: number };
}

interface Product {
  id: number;
  name: string;
  categoryId: number;
  category: ProductCategory;
  unit: string;
  currentStock: number;
  minStock: number;
  price: number;
  notes: string | null;
  _count?: { transactions: number };
}

interface InventoryTransaction {
  id: number;
  productId: number;
  product: Product;
  type: string;
  quantity: number;
  reason: string | null;
  recipient: string | null;
  supplier: string | null;
  price: number | null;
  notes: string | null;
  date: string;
}

interface Settings {
  adminUsername: string;
  adminPassword: string;
  companyName: string;
  companySlogan: string;
  supportPhone1: string;
  supportPhone2: string;
  supportName1: string;
  supportName2: string;
}

export default function Home() {
  // Auth State
  const [isAdmin, setIsAdmin] = useState(false);
  const [showLoginDialog, setShowLoginDialog] = useState(false);
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [settings, setSettings] = useState<Settings>({
    adminUsername: 'admin',
    adminPassword: 'admin12344321',
    companyName: 'جرمانا نت',
    companySlogan: 'اختيارك الأفضل - الإنترنت الأفضل في جرمانا',
    supportPhone1: '0992417870',
    supportPhone2: '0959128944',
    supportName1: 'Ghasan',
    supportName2: 'Ramzy',
  });

  // Data States
  const [subscribers, setSubscribers] = useState<Subscriber[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [inventoryTransactions, setInventoryTransactions] = useState<InventoryTransaction[]>([]);

  // UI States
  const [searchName, setSearchName] = useState('');
  const [searchResult, setSearchResult] = useState<SearchResult | null>(null);
  const [searchError, setSearchError] = useState('');
  const [loading, setLoading] = useState(false);
  const [fetchLoading, setFetchLoading] = useState(false);
  const [activeAdminTab, setActiveAdminTab] = useState('subscribers');

  // Form States
  const [newSubscriber, setNewSubscriber] = useState({
    name: '',
    phone: '',
    address: '',
    monthlyFee: 0,
  });

  const [editSubscriber, setEditSubscriber] = useState<Subscriber | null>(null);
  const [newInvoice, setNewInvoice] = useState({
    subscriberId: 0,
    month: '',
    amount: 0,
    notes: '',
  });

  const [invoiceSubscriberId, setInvoiceSubscriberId] = useState<number | null>(null);

  // Inventory Form States
  const [newCategory, setNewCategory] = useState({ name: '', nameEn: '', description: '' });
  const [newProduct, setNewProduct] = useState({
    name: '',
    categoryId: 0,
    unit: 'قطعة',
    currentStock: 0,
    minStock: 5,
    price: 0,
    notes: '',
  });
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [newTransaction, setNewTransaction] = useState({
    productId: 0,
    type: 'in',
    quantity: 1,
    reason: '',
    recipient: '',
    supplier: '',
    price: 0,
    notes: '',
  });

  // Settings Form
  const [settingsForm, setSettingsForm] = useState<Settings>(settings);

  // Load settings on mount
  useEffect(() => {
    fetchSettings();
  }, []);

  // Fetch data when admin mode changes
  useEffect(() => {
    if (isAdmin) {
      fetchSubscribers();
      fetchInvoices();
      fetchCategories();
      fetchProducts();
      fetchInventoryTransactions();
    }
  }, [isAdmin]);

  // Update settingsForm when settings change
  useEffect(() => {
    setSettingsForm(settings);
  }, [settings]);

  // API Functions
  const fetchSettings = async () => {
    try {
      const res = await fetch('/api/settings');
      const data = await res.json();
      setSettings(data);
    } catch (error) {
      console.error('Error fetching settings:', error);
    }
  };

  const fetchSubscribers = async () => {
    setFetchLoading(true);
    try {
      const res = await fetch('/api/subscribers');
      const data = await res.json();
      setSubscribers(data);
    } catch (error) {
      console.error('Error fetching subscribers:', error);
    } finally {
      setFetchLoading(false);
    }
  };

  const fetchInvoices = async () => {
    try {
      const res = await fetch('/api/invoices');
      const data = await res.json();
      setInvoices(data);
    } catch (error) {
      console.error('Error fetching invoices:', error);
    }
  };

  const fetchCategories = async () => {
    try {
      const res = await fetch('/api/categories');
      const data = await res.json();
      setCategories(data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchProducts = async () => {
    try {
      const res = await fetch('/api/products');
      const data = await res.json();
      setProducts(data);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const fetchInventoryTransactions = async () => {
    try {
      const res = await fetch('/api/inventory');
      const data = await res.json();
      setInventoryTransactions(data);
    } catch (error) {
      console.error('Error fetching inventory transactions:', error);
    }
  };

  // Handle Login
  const handleLogin = () => {
    if (loginUsername === settings.adminUsername && loginPassword === settings.adminPassword) {
      setIsAdmin(true);
      setShowLoginDialog(false);
      setLoginUsername('');
      setLoginPassword('');
      setLoginError('');
    } else {
      setLoginError('اسم المستخدم أو كلمة المرور غير صحيحة');
    }
  };

  // Handle Logout
  const handleLogout = () => {
    setIsAdmin(false);
    setSubscribers([]);
    setInvoices([]);
    setCategories([]);
    setProducts([]);
    setInventoryTransactions([]);
    setActiveAdminTab('subscribers');
  };

  // Search invoice by name
  const handleSearch = async () => {
    if (!searchName.trim() || searchName.trim().length < 3) {
      setSearchError('الرجاء إدخال الاسم الثلاثي كاملاً');
      return;
    }

    setLoading(true);
    setSearchError('');
    setSearchResult(null);

    try {
      const res = await fetch(`/api/check-invoice?name=${encodeURIComponent(searchName)}`);
      const data = await res.json();

      if (!res.ok) {
        setSearchError(data.error || 'حدث خطأ أثناء البحث');
      } else {
        setSearchResult(data);
      }
    } catch (error) {
      setSearchError('حدث خطأ أثناء البحث');
    } finally {
      setLoading(false);
    }
  };

  // Subscriber Functions
  const handleAddSubscriber = async () => {
    if (!newSubscriber.name || !newSubscriber.phone) {
      alert('الاسم ورقم الهاتف مطلوبان');
      return;
    }

    try {
      const res = await fetch('/api/subscribers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSubscriber),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.error || 'حدث خطأ');
        return;
      }

      setNewSubscriber({ name: '', phone: '', address: '', monthlyFee: 0 });
      fetchSubscribers();
      alert('تم إضافة المشترك بنجاح');
    } catch (error) {
      alert('حدث خطأ أثناء إضافة المشترك');
    }
  };

  const handleUpdateSubscriber = async () => {
    if (!editSubscriber) return;

    try {
      const res = await fetch(`/api/subscribers/${editSubscriber.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editSubscriber),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.error || 'حدث خطأ');
        return;
      }

      setEditSubscriber(null);
      fetchSubscribers();
      alert('تم تحديث المشترك بنجاح');
    } catch (error) {
      alert('حدث خطأ أثناء تحديث المشترك');
    }
  };

  const handleDeleteSubscriber = async (id: number) => {
    try {
      const res = await fetch(`/api/subscribers/${id}`, {
        method: 'DELETE',
      });

      if (!res.ok) {
        const data = await res.json();
        alert(data.error || 'حدث خطأ');
        return;
      }

      fetchSubscribers();
      fetchInvoices();
      alert('تم حذف المشترك بنجاح');
    } catch (error) {
      alert('حدث خطأ أثناء حذف المشترك');
    }
  };

  // Invoice Functions
  const handleAddInvoice = async () => {
    if (!newInvoice.subscriberId || !newInvoice.month || newInvoice.amount <= 0) {
      alert('جميع البيانات مطلوبة');
      return;
    }

    try {
      const res = await fetch('/api/invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newInvoice),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.error || 'حدث خطأ');
        return;
      }

      setNewInvoice({ subscriberId: 0, month: '', amount: 0, notes: '' });
      setInvoiceSubscriberId(null);
      fetchInvoices();
      fetchSubscribers();
      alert('تم إضافة الفاتورة بنجاح');
    } catch (error) {
      alert('حدث خطأ أثناء إضافة الفاتورة');
    }
  };

  const handleToggleInvoicePaid = async (invoice: Invoice) => {
    try {
      const res = await fetch(`/api/invoices/${invoice.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isPaid: !invoice.isPaid }),
      });

      if (!res.ok) {
        const data = await res.json();
        alert(data.error || 'حدث خطأ');
        return;
      }

      fetchInvoices();
      fetchSubscribers();
    } catch (error) {
      alert('حدث خطأ أثناء تحديث الفاتورة');
    }
  };

  // Category Functions
  const handleAddCategory = async () => {
    if (!newCategory.name) {
      alert('اسم التصنيف مطلوب');
      return;
    }

    try {
      const res = await fetch('/api/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newCategory),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.error || 'حدث خطأ');
        return;
      }

      setNewCategory({ name: '', nameEn: '', description: '' });
      fetchCategories();
      alert('تم إضافة التصنيف بنجاح');
    } catch (error) {
      alert('حدث خطأ أثناء إضافة التصنيف');
    }
  };

  const handleDeleteCategory = async (id: number) => {
    try {
      const res = await fetch(`/api/categories/${id}`, {
        method: 'DELETE',
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.error || 'حدث خطأ');
        return;
      }

      fetchCategories();
      alert('تم حذف التصنيف بنجاح');
    } catch (error) {
      alert('حدث خطأ أثناء حذف التصنيف');
    }
  };

  // Product Functions
  const handleAddProduct = async () => {
    if (!newProduct.name || !newProduct.categoryId) {
      alert('اسم المنتج والتصنيف مطلوبان');
      return;
    }

    try {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newProduct),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.error || 'حدث خطأ');
        return;
      }

      setNewProduct({
        name: '',
        categoryId: 0,
        unit: 'قطعة',
        currentStock: 0,
        minStock: 5,
        price: 0,
        notes: '',
      });
      fetchProducts();
      alert('تم إضافة المنتج بنجاح');
    } catch (error) {
      alert('حدث خطأ أثناء إضافة المنتج');
    }
  };

  const handleUpdateProduct = async () => {
    if (!editProduct) return;

    try {
      const res = await fetch(`/api/products/${editProduct.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editProduct),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.error || 'حدث خطأ');
        return;
      }

      setEditProduct(null);
      fetchProducts();
      alert('تم تحديث المنتج بنجاح');
    } catch (error) {
      alert('حدث خطأ أثناء تحديث المنتج');
    }
  };

  const handleDeleteProduct = async (id: number) => {
    try {
      const res = await fetch(`/api/products/${id}`, {
        method: 'DELETE',
      });

      if (!res.ok) {
        const data = await res.json();
        alert(data.error || 'حدث خطأ');
        return;
      }

      fetchProducts();
      fetchInventoryTransactions();
      alert('تم حذف المنتج بنجاح');
    } catch (error) {
      alert('حدث خطأ أثناء حذف المنتج');
    }
  };

  // Inventory Transaction Functions
  const handleAddTransaction = async () => {
    if (!newTransaction.productId || !newTransaction.quantity) {
      alert('المنتج والكمية مطلوبان');
      return;
    }

    try {
      const res = await fetch('/api/inventory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTransaction),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.error || 'حدث خطأ');
        return;
      }

      setNewTransaction({
        productId: 0,
        type: 'in',
        quantity: 1,
        reason: '',
        recipient: '',
        supplier: '',
        price: 0,
        notes: '',
      });
      fetchInventoryTransactions();
      fetchProducts();
      alert('تم إضافة الحركة بنجاح');
    } catch (error) {
      alert('حدث خطأ أثناء إضافة الحركة');
    }
  };

  // Settings Functions
  const handleSaveSettings = async () => {
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settingsForm),
      });

      if (!res.ok) {
        alert('حدث خطأ');
        return;
      }

      setSettings(settingsForm);
      alert('تم حفظ الإعدادات بنجاح');
    } catch (error) {
      alert('حدث خطأ أثناء حفظ الإعدادات');
    }
  };

  // Helper Functions
  const formatMonth = (month: string) => {
    const [year, m] = month.split('-');
    const months = [
      'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];
    return `${months[parseInt(m) - 1]} ${year}`;
  };

  const formatCurrency = (amount: number) => {
    return `${amount.toLocaleString('ar-EG')} ل.س`;
  };

  const getCurrentMonth = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    return `${year}-${month}`;
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('ar-EG');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900" dir="rtl">
      {/* Header */}
      <header className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border-b border-slate-700 shadow-xl">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="relative">
              <Image
                src="/logo.png"
                alt="جرمانا نت"
                width={60}
                height={60}
                className="rounded-full shadow-lg ring-2 ring-blue-500/50"
              />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-l from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                {settings.companyName}
              </h1>
              <p className="text-slate-400 text-sm">{settings.companySlogan}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 text-slate-300">
              <Wifi className="h-5 w-5 text-cyan-400" />
              <span className="text-sm">{settings.companySlogan}</span>
            </div>
            {isAdmin ? (
              <Button
                onClick={handleLogout}
                variant="destructive"
                className="gap-2 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 shadow-lg"
              >
                <LogOut className="h-4 w-4" />
                خروج
              </Button>
            ) : (
              <Button
                onClick={() => setShowLoginDialog(true)}
                className="gap-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 shadow-lg"
              >
                <Shield className="h-4 w-4" />
                دخول المسؤول
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Login Dialog */}
      <Dialog open={showLoginDialog} onOpenChange={setShowLoginDialog}>
        <DialogContent className="sm:max-w-md bg-slate-900 border-slate-700">
          <DialogHeader>
            <DialogTitle className="text-center text-xl text-white">تسجيل الدخول</DialogTitle>
            <DialogDescription className="text-center text-slate-400">
              أدخل بيانات المسؤول للدخول
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label className="text-slate-300">اسم المستخدم</Label>
              <Input
                value={loginUsername}
                onChange={(e) => setLoginUsername(e.target.value)}
                placeholder="أدخل اسم المستخدم"
                onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
                className="bg-slate-800 border-slate-600 text-white placeholder-slate-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">كلمة المرور</Label>
              <Input
                type="password"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                placeholder="أدخل كلمة المرور"
                onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
                className="bg-slate-800 border-slate-600 text-white placeholder-slate-500"
              />
            </div>
            {loginError && (
              <div className="bg-red-900/50 border border-red-700 text-red-300 px-4 py-2 rounded-lg text-sm">
                {loginError}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button
              onClick={handleLogin}
              className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
            >
              <LogIn className="h-4 w-4 ml-2" />
              دخول
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Visitor Interface */}
        {!isAdmin && (
          <div className="max-w-2xl mx-auto space-y-6">
            {/* Hero Card */}
            <Card className="bg-slate-800/80 backdrop-blur-xl shadow-2xl border-slate-700">
              <CardHeader className="text-center bg-gradient-to-r from-blue-600 via-cyan-600 to-blue-600 text-white rounded-t-lg">
                <div className="flex justify-center mb-4">
                  <Image
                    src="/logo.png"
                    alt="جرمانا نت"
                    width={80}
                    height={80}
                    className="rounded-full shadow-xl ring-4 ring-white/30"
                  />
                </div>
                <CardTitle className="text-2xl">الاستعلام عن الفاتورة</CardTitle>
                <CardDescription className="text-blue-100">
                  أدخل اسمك الثلاثي للاستعلام عن حالة الفواتير
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                {/* Search Form */}
                <div className="flex gap-2">
                  <Input
                    placeholder="أدخل الاسم الثلاثي كاملاً"
                    value={searchName}
                    onChange={(e) => setSearchName(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                    className="text-lg h-12 bg-slate-700/50 border-slate-600 text-white placeholder-slate-400 focus:border-cyan-500"
                  />
                  <Button
                    onClick={handleSearch}
                    disabled={loading}
                    className="h-12 px-6 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
                  >
                    {loading ? (
                      <Loader2 className="h-5 w-5 animate-spin" />
                    ) : (
                      <Search className="h-5 w-5" />
                    )}
                  </Button>
                </div>

                {/* Error Message */}
                {searchError && (
                  <div className="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg">
                    {searchError}
                  </div>
                )}

                {/* Search Result */}
                {searchResult && (
                  <div className="space-y-6">
                    {/* Subscriber Info */}
                    <div className="bg-gradient-to-r from-slate-700/50 to-slate-600/50 p-4 rounded-lg border border-slate-600">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="text-xl font-semibold text-white">
                            {searchResult.subscriber.name}
                          </h3>
                          <p className="text-slate-400">{searchResult.subscriber.phone}</p>
                        </div>
                        <Badge
                          variant={searchResult.subscriber.isActive ? 'default' : 'destructive'}
                          className={searchResult.subscriber.isActive ? 'bg-gradient-to-r from-green-500 to-emerald-500' : ''}
                        >
                          {searchResult.subscriber.isActive ? 'نشط' : 'متوقف'}
                        </Badge>
                      </div>
                      {searchResult.subscriber.address && (
                        <p className="text-slate-400 text-sm">
                          العنوان: {searchResult.subscriber.address}
                        </p>
                      )}
                      <p className="text-slate-400 text-sm">
                        الرسوم الشهرية: {formatCurrency(searchResult.subscriber.monthlyFee)}
                      </p>
                    </div>

                    {/* Total Due */}
                    {searchResult.totalDue > 0 && (
                      <div className="bg-gradient-to-r from-red-900/50 to-red-800/50 border-2 border-red-600/50 p-4 rounded-lg shadow-lg">
                        <div className="flex justify-between items-center">
                          <span className="text-red-300 font-bold text-lg">إجمالي المبلغ المستحق:</span>
                          <span className="text-red-300 font-bold text-2xl">
                            {formatCurrency(searchResult.totalDue)}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* No Due */}
                    {searchResult.totalDue === 0 && (
                      <div className="bg-gradient-to-r from-green-900/50 to-emerald-900/50 border-2 border-green-600/50 p-4 rounded-lg shadow-lg">
                        <div className="flex justify-center items-center gap-2">
                          <CheckCircle className="h-6 w-6 text-green-400" />
                          <span className="text-green-300 font-bold text-lg">مبروك! لا يوجد فواتير مستحقة</span>
                        </div>
                      </div>
                    )}

                    {/* Invoices List */}
                    <div>
                      <h4 className="font-semibold text-white mb-3 flex items-center gap-2">
                        <FileText className="h-5 w-5 text-cyan-400" />
                        الفواتير
                      </h4>
                      {searchResult.subscriber.invoices && searchResult.subscriber.invoices.length > 0 ? (
                        <div className="space-y-2">
                          {searchResult.subscriber.invoices.map((invoice) => (
                            <div
                              key={invoice.id}
                              className={`p-3 rounded-lg border-2 ${
                                invoice.isPaid
                                  ? 'bg-green-900/30 border-green-700/50'
                                  : 'bg-red-900/30 border-red-700/50'
                              }`}
                            >
                              <div className="flex justify-between items-center">
                                <div>
                                  <p className="font-medium text-white">
                                    {formatMonth(invoice.month)}
                                  </p>
                                  {invoice.notes && (
                                    <p className="text-sm text-slate-400">{invoice.notes}</p>
                                  )}
                                </div>
                                <div className="text-left">
                                  <p className="font-semibold text-white">
                                    {formatCurrency(invoice.amount)}
                                  </p>
                                  <Badge
                                    variant={invoice.isPaid ? 'default' : 'destructive'}
                                    className={invoice.isPaid ? 'bg-gradient-to-r from-green-500 to-emerald-500' : ''}
                                  >
                                    {invoice.isPaid ? 'مدفوعة' : 'غير مدفوعة'}
                                  </Badge>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-slate-400 text-center py-4">لا توجد فواتير</p>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Support Card */}
            <Card className="bg-slate-800/80 backdrop-blur-xl shadow-xl border-slate-700">
              <CardHeader className="bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-t-lg">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Phone className="h-5 w-5" />
                  للدعم الفني والتواصل
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-slate-700/50 p-4 rounded-lg text-center border border-slate-600">
                    <p className="font-bold text-cyan-400 text-lg">{settings.supportName1}</p>
                    <a href={`tel:${settings.supportPhone1}`} className="text-white hover:text-cyan-400 text-xl font-semibold">
                      {settings.supportPhone1}
                    </a>
                  </div>
                  <div className="bg-slate-700/50 p-4 rounded-lg text-center border border-slate-600">
                    <p className="font-bold text-cyan-400 text-lg">{settings.supportName2}</p>
                    <a href={`tel:${settings.supportPhone2}`} className="text-white hover:text-cyan-400 text-xl font-semibold">
                      {settings.supportPhone2}
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Footer Credit */}
            <div className="text-center py-4">
              <p className="text-slate-400 text-sm">
                By Eng Ramzy Amoory
              </p>
            </div>
          </div>
        )}

        {/* Admin Interface */}
        {isAdmin && (
          <Tabs value={activeAdminTab} onValueChange={setActiveAdminTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-5 bg-slate-800 border border-slate-700">
              <TabsTrigger value="subscribers" className="gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-cyan-600">
                <Users className="h-4 w-4" />
                <span className="hidden sm:inline">المشتركين</span>
              </TabsTrigger>
              <TabsTrigger value="invoices" className="gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-cyan-600">
                <FileText className="h-4 w-4" />
                <span className="hidden sm:inline">الفواتير</span>
              </TabsTrigger>
              <TabsTrigger value="inventory" className="gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-cyan-600">
                <Package className="h-4 w-4" />
                <span className="hidden sm:inline">المخزون</span>
              </TabsTrigger>
              <TabsTrigger value="products" className="gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-cyan-600">
                <Box className="h-4 w-4" />
                <span className="hidden sm:inline">المنتجات</span>
              </TabsTrigger>
              <TabsTrigger value="settings" className="gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-cyan-600">
                <Settings className="h-4 w-4" />
                <span className="hidden sm:inline">إعدادات</span>
              </TabsTrigger>
            </TabsList>

            {/* Subscribers Tab */}
            <TabsContent value="subscribers">
              <Card className="bg-slate-800/80 backdrop-blur border-slate-700">
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle className="text-cyan-400">قائمة المشتركين</CardTitle>
                      <CardDescription className="text-slate-400">إدارة جميع المشتركين في النظام</CardDescription>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button className="bg-gradient-to-r from-blue-600 to-cyan-600">
                          <UserPlus className="h-4 w-4 ml-2" />
                          إضافة مشترك
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="bg-slate-900 border-slate-700">
                        <DialogHeader>
                          <DialogTitle className="text-white">إضافة مشترك جديد</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label className="text-slate-300">الاسم الثلاثي *</Label>
                            <Input
                              value={newSubscriber.name}
                              onChange={(e) => setNewSubscriber({ ...newSubscriber, name: e.target.value })}
                              placeholder="أدخل الاسم الثلاثي كاملاً"
                              className="bg-slate-800 border-slate-600 text-white"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label className="text-slate-300">رقم الهاتف *</Label>
                            <Input
                              value={newSubscriber.phone}
                              onChange={(e) => setNewSubscriber({ ...newSubscriber, phone: e.target.value })}
                              placeholder="أدخل رقم الهاتف"
                              className="bg-slate-800 border-slate-600 text-white"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label className="text-slate-300">العنوان</Label>
                            <Input
                              value={newSubscriber.address}
                              onChange={(e) => setNewSubscriber({ ...newSubscriber, address: e.target.value })}
                              placeholder="أدخل العنوان"
                              className="bg-slate-800 border-slate-600 text-white"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label className="text-slate-300">الرسوم الشهرية (ل.س)</Label>
                            <Input
                              type="number"
                              value={newSubscriber.monthlyFee}
                              onChange={(e) => setNewSubscriber({ ...newSubscriber, monthlyFee: parseFloat(e.target.value) || 0 })}
                              className="bg-slate-800 border-slate-600 text-white"
                            />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button onClick={handleAddSubscriber} className="bg-gradient-to-r from-blue-600 to-cyan-600">
                            إضافة
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardHeader>
                <CardContent>
                  {fetchLoading ? (
                    <div className="flex justify-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
                    </div>
                  ) : subscribers.length > 0 ? (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="border-slate-700 hover:bg-slate-700/50">
                            <TableHead className="text-slate-300">الاسم</TableHead>
                            <TableHead className="text-slate-300">الهاتف</TableHead>
                            <TableHead className="text-slate-300">العنوان</TableHead>
                            <TableHead className="text-slate-300">الرسوم</TableHead>
                            <TableHead className="text-slate-300">الحالة</TableHead>
                            <TableHead className="text-slate-300">المستحق</TableHead>
                            <TableHead className="text-slate-300 text-center">الإجراءات</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {subscribers.map((subscriber) => {
                            const totalDue = subscriber.invoices?.filter((inv) => !inv.isPaid).reduce((sum, inv) => sum + inv.amount, 0) || 0;
                            return (
                              <TableRow key={subscriber.id} className="border-slate-700 hover:bg-slate-700/30">
                                <TableCell className="font-medium text-white">{subscriber.name}</TableCell>
                                <TableCell className="text-slate-300">{subscriber.phone}</TableCell>
                                <TableCell className="text-slate-300">{subscriber.address || '-'}</TableCell>
                                <TableCell className="text-slate-300">{formatCurrency(subscriber.monthlyFee)}</TableCell>
                                <TableCell>
                                  <Badge className={subscriber.isActive ? 'bg-gradient-to-r from-green-500 to-emerald-500' : 'bg-red-500'}>
                                    {subscriber.isActive ? 'نشط' : 'متوقف'}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  {totalDue > 0 ? (
                                    <span className="text-red-400 font-medium">{formatCurrency(totalDue)}</span>
                                  ) : (
                                    <span className="text-green-400">لا يوجد</span>
                                  )}
                                </TableCell>
                                <TableCell>
                                  <div className="flex gap-2 justify-center">
                                    {/* Edit Dialog */}
                                    <Dialog>
                                      <DialogTrigger asChild>
                                        <Button variant="outline" size="sm" className="border-blue-500/50 text-blue-400 hover:bg-blue-500/20" onClick={() => setEditSubscriber(subscriber)}>
                                          <Edit className="h-4 w-4" />
                                        </Button>
                                      </DialogTrigger>
                                      <DialogContent className="bg-slate-900 border-slate-700">
                                        <DialogHeader>
                                          <DialogTitle className="text-white">تعديل بيانات المشترك</DialogTitle>
                                        </DialogHeader>
                                        {editSubscriber && (
                                          <div className="space-y-4 py-4">
                                            <div className="space-y-2">
                                              <Label className="text-slate-300">الاسم</Label>
                                              <Input value={editSubscriber.name} onChange={(e) => setEditSubscriber({ ...editSubscriber, name: e.target.value })} className="bg-slate-800 border-slate-600 text-white" />
                                            </div>
                                            <div className="space-y-2">
                                              <Label className="text-slate-300">رقم الهاتف</Label>
                                              <Input value={editSubscriber.phone} onChange={(e) => setEditSubscriber({ ...editSubscriber, phone: e.target.value })} className="bg-slate-800 border-slate-600 text-white" />
                                            </div>
                                            <div className="space-y-2">
                                              <Label className="text-slate-300">العنوان</Label>
                                              <Input value={editSubscriber.address || ''} onChange={(e) => setEditSubscriber({ ...editSubscriber, address: e.target.value })} className="bg-slate-800 border-slate-600 text-white" />
                                            </div>
                                            <div className="space-y-2">
                                              <Label className="text-slate-300">الرسوم الشهرية</Label>
                                              <Input type="number" value={editSubscriber.monthlyFee} onChange={(e) => setEditSubscriber({ ...editSubscriber, monthlyFee: parseFloat(e.target.value) || 0 })} className="bg-slate-800 border-slate-600 text-white" />
                                            </div>
                                            <div className="flex items-center justify-between">
                                              <Label className="text-slate-300">نشط</Label>
                                              <Switch checked={editSubscriber.isActive} onCheckedChange={(checked) => setEditSubscriber({ ...editSubscriber, isActive: checked })} />
                                            </div>
                                          </div>
                                        )}
                                        <DialogFooter>
                                          <Button onClick={handleUpdateSubscriber} className="bg-gradient-to-r from-blue-600 to-cyan-600">حفظ</Button>
                                        </DialogFooter>
                                      </DialogContent>
                                    </Dialog>

                                    {/* Add Invoice Dialog */}
                                    <Dialog>
                                      <DialogTrigger asChild>
                                        <Button variant="outline" size="sm" className="border-green-500/50 text-green-400 hover:bg-green-500/20" onClick={() => { setInvoiceSubscriberId(subscriber.id); setNewInvoice({ subscriberId: subscriber.id, month: getCurrentMonth(), amount: subscriber.monthlyFee, notes: '' }); }}>
                                          <Plus className="h-4 w-4" />
                                        </Button>
                                      </DialogTrigger>
                                      <DialogContent className="bg-slate-900 border-slate-700">
                                        <DialogHeader>
                                          <DialogTitle className="text-white">إضافة فاتورة جديدة</DialogTitle>
                                          <DialogDescription className="text-slate-400">إضافة فاتورة للمشترك: {subscriber.name}</DialogDescription>
                                        </DialogHeader>
                                        <div className="space-y-4 py-4">
                                          <div className="space-y-2">
                                            <Label className="text-slate-300">الشهر</Label>
                                            <Input type="month" value={newInvoice.month} onChange={(e) => setNewInvoice({ ...newInvoice, month: e.target.value })} className="bg-slate-800 border-slate-600 text-white" />
                                          </div>
                                          <div className="space-y-2">
                                            <Label className="text-slate-300">المبلغ</Label>
                                            <Input type="number" value={newInvoice.amount} onChange={(e) => setNewInvoice({ ...newInvoice, amount: parseFloat(e.target.value) || 0 })} className="bg-slate-800 border-slate-600 text-white" />
                                          </div>
                                          <div className="space-y-2">
                                            <Label className="text-slate-300">ملاحظات</Label>
                                            <Textarea value={newInvoice.notes} onChange={(e) => setNewInvoice({ ...newInvoice, notes: e.target.value })} className="bg-slate-800 border-slate-600 text-white" />
                                          </div>
                                        </div>
                                        <DialogFooter>
                                          <Button onClick={handleAddInvoice} className="bg-gradient-to-r from-green-600 to-emerald-600">إضافة الفاتورة</Button>
                                        </DialogFooter>
                                      </DialogContent>
                                    </Dialog>

                                    {/* Delete Alert */}
                                    <AlertDialog>
                                      <AlertDialogTrigger asChild>
                                        <Button variant="destructive" size="sm">
                                          <Trash2 className="h-4 w-4" />
                                        </Button>
                                      </AlertDialogTrigger>
                                      <AlertDialogContent className="bg-slate-900 border-slate-700">
                                        <AlertDialogHeader>
                                          <AlertDialogTitle className="text-white">حذف المشترك</AlertDialogTitle>
                                          <AlertDialogDescription className="text-slate-400">
                                            هل أنت متأكد من حذف المشترك &quot;{subscriber.name}&quot;؟ سيتم حذف جميع الفواتير المرتبطة به أيضاً.
                                          </AlertDialogDescription>
                                        </AlertDialogHeader>
                                        <AlertDialogFooter>
                                          <AlertDialogCancel className="bg-slate-700 text-white border-slate-600">إلغاء</AlertDialogCancel>
                                          <AlertDialogAction onClick={() => handleDeleteSubscriber(subscriber.id)} className="bg-red-600 hover:bg-red-700">حذف</AlertDialogAction>
                                        </AlertDialogFooter>
                                      </AlertDialogContent>
                                    </AlertDialog>
                                  </div>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </div>
                  ) : (
                    <p className="text-center text-slate-400 py-8">لا يوجد مشتركين</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Invoices Tab */}
            <TabsContent value="invoices">
              <Card className="bg-slate-800/80 backdrop-blur border-slate-700">
                <CardHeader>
                  <CardTitle className="text-cyan-400">قائمة الفواتير</CardTitle>
                  <CardDescription className="text-slate-400">إدارة جميع الفواتير في النظام</CardDescription>
                </CardHeader>
                <CardContent>
                  {invoices.length > 0 ? (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="border-slate-700 hover:bg-slate-700/50">
                            <TableHead className="text-slate-300">المشترك</TableHead>
                            <TableHead className="text-slate-300">الشهر</TableHead>
                            <TableHead className="text-slate-300">المبلغ</TableHead>
                            <TableHead className="text-slate-300">الحالة</TableHead>
                            <TableHead className="text-slate-300">تاريخ الاستحقاق</TableHead>
                            <TableHead className="text-slate-300 text-center">الإجراءات</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {invoices.map((invoice) => (
                            <TableRow key={invoice.id} className="border-slate-700 hover:bg-slate-700/30">
                              <TableCell className="font-medium text-white">{invoice.subscriber?.name}</TableCell>
                              <TableCell className="text-slate-300">{formatMonth(invoice.month)}</TableCell>
                              <TableCell className="text-slate-300">{formatCurrency(invoice.amount)}</TableCell>
                              <TableCell>
                                <Badge className={invoice.isPaid ? 'bg-gradient-to-r from-green-500 to-emerald-500' : 'bg-red-500'}>
                                  {invoice.isPaid ? 'مدفوعة' : 'غير مدفوعة'}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-slate-300">{formatDate(invoice.dueDate)}</TableCell>
                              <TableCell className="text-center">
                                <Button
                                  variant={invoice.isPaid ? 'destructive' : 'default'}
                                  size="sm"
                                  onClick={() => handleToggleInvoicePaid(invoice)}
                                  className={invoice.isPaid ? '' : 'bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700'}
                                >
                                  {invoice.isPaid ? (
                                    <>
                                      <XCircle className="h-4 w-4 ml-1" />
                                      إلغاء الدفع
                                    </>
                                  ) : (
                                    <>
                                      <CheckCircle className="h-4 w-4 ml-1" />
                                      تأكيد الدفع
                                    </>
                                  )}
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  ) : (
                    <p className="text-center text-slate-400 py-8">لا توجد فواتير</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Inventory Tab */}
            <TabsContent value="inventory">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Add Transaction Card */}
                <Card className="bg-slate-800/80 backdrop-blur border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-cyan-400 flex items-center gap-2">
                      <Package className="h-5 w-5" />
                      إضافة حركة مخزون
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label className="text-slate-300">المنتج</Label>
                        <Select value={newTransaction.productId.toString()} onValueChange={(v) => setNewTransaction({ ...newTransaction, productId: parseInt(v) })}>
                          <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                            <SelectValue placeholder="اختر المنتج" />
                          </SelectTrigger>
                          <SelectContent className="bg-slate-800 border-slate-600">
                            {products.map((p) => (
                              <SelectItem key={p.id} value={p.id.toString()} className="text-white hover:bg-slate-700">
                                {p.name} ({p.category.name}) - المخزون: {p.currentStock}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-slate-300">نوع الحركة</Label>
                        <div className="flex gap-2">
                          <Button
                            variant={newTransaction.type === 'in' ? 'default' : 'outline'}
                            onClick={() => setNewTransaction({ ...newTransaction, type: 'in' })}
                            className={`flex-1 gap-2 ${newTransaction.type === 'in' ? 'bg-gradient-to-r from-green-600 to-emerald-600' : 'border-green-500/50 text-green-400'}`}
                          >
                            <ArrowDownCircle className="h-4 w-4" />
                            داخل
                          </Button>
                          <Button
                            variant={newTransaction.type === 'out' ? 'default' : 'outline'}
                            onClick={() => setNewTransaction({ ...newTransaction, type: 'out' })}
                            className={`flex-1 gap-2 ${newTransaction.type === 'out' ? 'bg-gradient-to-r from-red-600 to-orange-600' : 'border-red-500/50 text-red-400'}`}
                          >
                            <ArrowUpCircle className="h-4 w-4" />
                            خارج
                          </Button>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-slate-300">الكمية</Label>
                        <Input type="number" value={newTransaction.quantity} onChange={(e) => setNewTransaction({ ...newTransaction, quantity: parseInt(e.target.value) || 0 })} className="bg-slate-700 border-slate-600 text-white" />
                      </div>
                      {newTransaction.type === 'in' ? (
                        <div className="space-y-2">
                          <Label className="text-slate-300">المورد</Label>
                          <Input value={newTransaction.supplier} onChange={(e) => setNewTransaction({ ...newTransaction, supplier: e.target.value })} placeholder="اسم المورد" className="bg-slate-700 border-slate-600 text-white" />
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <Label className="text-slate-300">المستلم</Label>
                          <Input value={newTransaction.recipient} onChange={(e) => setNewTransaction({ ...newTransaction, recipient: e.target.value })} placeholder="اسم المستلم" className="bg-slate-700 border-slate-600 text-white" />
                        </div>
                      )}
                      <div className="space-y-2">
                        <Label className="text-slate-300">السبب / الملاحظات</Label>
                        <Textarea value={newTransaction.notes} onChange={(e) => setNewTransaction({ ...newTransaction, notes: e.target.value })} className="bg-slate-700 border-slate-600 text-white" />
                      </div>
                      <Button onClick={handleAddTransaction} className="w-full bg-gradient-to-r from-blue-600 to-cyan-600">
                        <Save className="h-4 w-4 ml-2" />
                        حفظ الحركة
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Transactions List */}
                <Card className="bg-slate-800/80 backdrop-blur border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-cyan-400">سجل حركات المخزون</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {inventoryTransactions.length > 0 ? (
                      <div className="space-y-2 max-h-96 overflow-y-auto">
                        {inventoryTransactions.slice(0, 20).map((t) => (
                          <div key={t.id} className={`p-3 rounded-lg border ${t.type === 'in' ? 'bg-green-900/30 border-green-700/50' : 'bg-red-900/30 border-red-700/50'}`}>
                            <div className="flex justify-between items-start">
                              <div>
                                <p className="font-medium text-white">{t.product.name}</p>
                                <p className="text-sm text-slate-400">{t.type === 'in' ? `من: ${t.supplier || '-'}` : `إلى: ${t.recipient || '-'}`}</p>
                              </div>
                              <div className="text-left">
                                <p className={`font-bold ${t.type === 'in' ? 'text-green-400' : 'text-red-400'}`}>
                                  {t.type === 'in' ? '+' : '-'}{t.quantity}
                                </p>
                                <p className="text-xs text-slate-500">{formatDate(t.date)}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-center text-slate-400 py-8">لا توجد حركات</p>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Products Tab */}
            <TabsContent value="products">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Categories Card */}
                <Card className="bg-slate-800/80 backdrop-blur border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-cyan-400 flex items-center gap-2">
                      <Layers className="h-5 w-5" />
                      التصنيفات
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Input value={newCategory.name} onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })} placeholder="اسم التصنيف" className="bg-slate-700 border-slate-600 text-white" />
                        <Button onClick={handleAddCategory} className="w-full bg-gradient-to-r from-blue-600 to-cyan-600">
                          <Plus className="h-4 w-4 ml-2" />
                          إضافة تصنيف
                        </Button>
                      </div>
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {categories.map((cat) => (
                          <div key={cat.id} className="flex justify-between items-center p-2 bg-slate-700/50 rounded-lg">
                            <span className="text-white">{cat.name}</span>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="border-slate-600 text-slate-300">{cat._count?.products || 0}</Badge>
                              <Button variant="ghost" size="sm" onClick={() => handleDeleteCategory(cat.id)} className="text-red-400 hover:text-red-300">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Add Product Card */}
                <Card className="bg-slate-800/80 backdrop-blur border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-cyan-400 flex items-center gap-2">
                      <Box className="h-5 w-5" />
                      إضافة منتج
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label className="text-slate-300">اسم المنتج</Label>
                        <Input value={newProduct.name} onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })} className="bg-slate-700 border-slate-600 text-white" />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-slate-300">التصنيف</Label>
                        <Select value={newProduct.categoryId.toString()} onValueChange={(v) => setNewProduct({ ...newProduct, categoryId: parseInt(v) })}>
                          <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                            <SelectValue placeholder="اختر التصنيف" />
                          </SelectTrigger>
                          <SelectContent className="bg-slate-800 border-slate-600">
                            {categories.map((c) => (
                              <SelectItem key={c.id} value={c.id.toString()} className="text-white hover:bg-slate-700">{c.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-2">
                          <Label className="text-slate-300">الوحدة</Label>
                          <Input value={newProduct.unit} onChange={(e) => setNewProduct({ ...newProduct, unit: e.target.value })} className="bg-slate-700 border-slate-600 text-white" />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-slate-300">الحد الأدنى</Label>
                          <Input type="number" value={newProduct.minStock} onChange={(e) => setNewProduct({ ...newProduct, minStock: parseInt(e.target.value) || 0 })} className="bg-slate-700 border-slate-600 text-white" />
                        </div>
                      </div>
                      <Button onClick={handleAddProduct} className="w-full bg-gradient-to-r from-blue-600 to-cyan-600">
                        <Plus className="h-4 w-4 ml-2" />
                        إضافة المنتج
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Products List Card */}
                <Card className="bg-slate-800/80 backdrop-blur border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-cyan-400">المنتجات والمخزون</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 max-h-96 overflow-y-auto">
                      {products.map((p) => (
                        <div key={p.id} className={`p-3 rounded-lg border ${p.currentStock <= p.minStock ? 'bg-red-900/30 border-red-700/50' : 'bg-slate-700/50 border-slate-600'}`}>
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="font-medium text-white">{p.name}</p>
                              <p className="text-xs text-slate-400">{p.category.name}</p>
                            </div>
                            <div className="flex items-center gap-2">
                              <div className="text-left">
                                <p className={`font-bold ${p.currentStock <= p.minStock ? 'text-red-400' : 'text-green-400'}`}>{p.currentStock}</p>
                                <p className="text-xs text-slate-500">{p.unit}</p>
                              </div>
                              {p.currentStock <= p.minStock && (
                                <AlertTriangle className="h-4 w-4 text-red-400" />
                              )}
                              <Button variant="ghost" size="sm" onClick={() => handleDeleteProduct(p.id)} className="text-red-400 hover:text-red-300">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings">
              <div className="max-w-2xl mx-auto">
                <Card className="bg-slate-800/80 backdrop-blur border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-cyan-400 flex items-center gap-2">
                      <Settings className="h-5 w-5" />
                      إعدادات النظام
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {/* Admin Credentials */}
                      <div className="p-4 bg-slate-700/50 rounded-lg border border-slate-600">
                        <h3 className="text-white font-semibold mb-4">بيانات المسؤول</h3>
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label className="text-slate-300">اسم المستخدم</Label>
                            <Input value={settingsForm.adminUsername} onChange={(e) => setSettingsForm({ ...settingsForm, adminUsername: e.target.value })} className="bg-slate-700 border-slate-600 text-white" />
                          </div>
                          <div className="space-y-2">
                            <Label className="text-slate-300">كلمة المرور</Label>
                            <Input type="password" value={settingsForm.adminPassword} onChange={(e) => setSettingsForm({ ...settingsForm, adminPassword: e.target.value })} className="bg-slate-700 border-slate-600 text-white" />
                          </div>
                        </div>
                      </div>

                      {/* Company Info */}
                      <div className="p-4 bg-slate-700/50 rounded-lg border border-slate-600">
                        <h3 className="text-white font-semibold mb-4">معلومات الشركة</h3>
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label className="text-slate-300">اسم الشركة</Label>
                            <Input value={settingsForm.companyName} onChange={(e) => setSettingsForm({ ...settingsForm, companyName: e.target.value })} className="bg-slate-700 border-slate-600 text-white" />
                          </div>
                          <div className="space-y-2">
                            <Label className="text-slate-300">الشعار</Label>
                            <Input value={settingsForm.companySlogan} onChange={(e) => setSettingsForm({ ...settingsForm, companySlogan: e.target.value })} className="bg-slate-700 border-slate-600 text-white" />
                          </div>
                        </div>
                      </div>

                      {/* Support Numbers */}
                      <div className="p-4 bg-slate-700/50 rounded-lg border border-slate-600">
                        <h3 className="text-white font-semibold mb-4">أرقام الدعم</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label className="text-slate-300">اسم الدعم 1</Label>
                            <Input value={settingsForm.supportName1} onChange={(e) => setSettingsForm({ ...settingsForm, supportName1: e.target.value })} className="bg-slate-700 border-slate-600 text-white" />
                          </div>
                          <div className="space-y-2">
                            <Label className="text-slate-300">رقم الهاتف 1</Label>
                            <Input value={settingsForm.supportPhone1} onChange={(e) => setSettingsForm({ ...settingsForm, supportPhone1: e.target.value })} className="bg-slate-700 border-slate-600 text-white" />
                          </div>
                          <div className="space-y-2">
                            <Label className="text-slate-300">اسم الدعم 2</Label>
                            <Input value={settingsForm.supportName2} onChange={(e) => setSettingsForm({ ...settingsForm, supportName2: e.target.value })} className="bg-slate-700 border-slate-600 text-white" />
                          </div>
                          <div className="space-y-2">
                            <Label className="text-slate-300">رقم الهاتف 2</Label>
                            <Input value={settingsForm.supportPhone2} onChange={(e) => setSettingsForm({ ...settingsForm, supportPhone2: e.target.value })} className="bg-slate-700 border-slate-600 text-white" />
                          </div>
                        </div>
                      </div>

                      <Button onClick={handleSaveSettings} className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 h-12">
                        <Save className="h-5 w-5 ml-2" />
                        حفظ الإعدادات
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-700/50 bg-slate-900/50 mt-8 py-4">
        <div className="max-w-7xl mx-auto px-4 text-center text-slate-400 text-sm">
          <p className="flex items-center justify-center gap-2 mb-2">
            <Wifi className="h-4 w-4 text-cyan-400" />
            {settings.companySlogan}
          </p>
          <p>{settings.companyName} © {new Date().getFullYear()} - By Eng Ramzy Amoory</p>
        </div>
      </footer>
    </div>
  );
}
