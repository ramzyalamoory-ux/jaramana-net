import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - البحث عن فاتورة مشترك بالاسم الثلاثي
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const name = searchParams.get('name');

    if (!name || name.trim().length < 3) {
      return NextResponse.json(
        { error: 'الرجاء إدخال الاسم الثلاثي كاملاً' },
        { status: 400 }
      );
    }

    // البحث بالاسم (يحتوي على)
    const subscriber = await db.subscriber.findFirst({
      where: {
        name: {
          contains: name.trim(),
        },
      },
      include: {
        invoices: {
          orderBy: {
            month: 'desc',
          },
        },
      },
    });

    if (!subscriber) {
      return NextResponse.json(
        { error: 'لا يوجد مشترك بهذا الاسم' },
        { status: 404 }
      );
    }

    // حساب إجمالي المبلغ المستحق
    const totalDue = subscriber.invoices
      .filter((invoice) => !invoice.isPaid)
      .reduce((sum, invoice) => sum + invoice.amount, 0);

    return NextResponse.json({
      subscriber,
      totalDue,
    });
  } catch (error) {
    console.error('Error checking invoice:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء البحث عن الفاتورة' },
      { status: 500 }
    );
  }
}
