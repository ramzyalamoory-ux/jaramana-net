import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - جلب كل المشتركين
export async function GET() {
  try {
    const subscribers = await db.subscriber.findMany({
      include: {
        invoices: {
          orderBy: {
            month: 'desc',
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });
    return NextResponse.json(subscribers);
  } catch (error) {
    console.error('Error fetching subscribers:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب المشتركين' },
      { status: 500 }
    );
  }
}

// POST - إضافة مشترك جديد
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, phone, address, monthlyFee, isActive } = body;

    // التحقق من البيانات المطلوبة
    if (!name || !phone) {
      return NextResponse.json(
        { error: 'الاسم ورقم الهاتف مطلوبان' },
        { status: 400 }
      );
    }

    // التحقق من عدم وجود مشترك بنفس رقم الهاتف
    const existingSubscriber = await db.subscriber.findUnique({
      where: { phone },
    });

    if (existingSubscriber) {
      return NextResponse.json(
        { error: 'يوجد مشترك بنفس رقم الهاتف' },
        { status: 400 }
      );
    }

    const subscriber = await db.subscriber.create({
      data: {
        name,
        phone,
        address: address || null,
        monthlyFee: monthlyFee || 0,
        isActive: isActive ?? true,
      },
    });

    return NextResponse.json(subscriber, { status: 201 });
  } catch (error) {
    console.error('Error creating subscriber:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء إضافة المشترك' },
      { status: 500 }
    );
  }
}
