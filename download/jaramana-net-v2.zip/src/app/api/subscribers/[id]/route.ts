import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// PUT - تحديث بيانات مشترك
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { 
      name, 
      phone, 
      address, 
      monthlyFee, 
      isActive,
      pppoeUser,
      pppoePassword,
      ipAddress,
      graceDays,
    } = body;

    // التحقق من وجود المشترك
    const existingSubscriber = await db.subscriber.findUnique({
      where: { id: parseInt(id) },
    });

    if (!existingSubscriber) {
      return NextResponse.json(
        { error: 'المشترك غير موجود' },
        { status: 404 }
      );
    }

    // التحقق من عدم وجود مشترك آخر بنفس رقم الهاتف
    if (phone && phone !== existingSubscriber.phone) {
      const phoneExists = await db.subscriber.findUnique({
        where: { phone },
      });

      if (phoneExists) {
        return NextResponse.json(
          { error: 'يوجد مشترك آخر بنفس رقم الهاتف' },
          { status: 400 }
        );
      }
    }

    // التحقق من عدم وجود مستخدم PPPoE مكرر
    if (pppoeUser && pppoeUser !== existingSubscriber.pppoeUser) {
      const pppoeExists = await db.subscriber.findUnique({
        where: { pppoeUser },
      });

      if (pppoeExists) {
        return NextResponse.json(
          { error: 'يوجد مشترك آخر بنفس اسم مستخدم PPPoE' },
          { status: 400 }
        );
      }
    }

    const subscriber = await db.subscriber.update({
      where: { id: parseInt(id) },
      data: {
        name: name ?? existingSubscriber.name,
        phone: phone ?? existingSubscriber.phone,
        address: address !== undefined ? address : existingSubscriber.address,
        monthlyFee: monthlyFee ?? existingSubscriber.monthlyFee,
        isActive: isActive ?? existingSubscriber.isActive,
        pppoeUser: pppoeUser !== undefined ? pppoeUser : existingSubscriber.pppoeUser,
        pppoePassword: pppoePassword !== undefined ? pppoePassword : existingSubscriber.pppoePassword,
        ipAddress: ipAddress !== undefined ? ipAddress : existingSubscriber.ipAddress,
        graceDays: graceDays !== undefined ? graceDays : existingSubscriber.graceDays,
        expiryDate: body.expiryDate !== undefined ? body.expiryDate ? new Date(body.expiryDate) : null : existingSubscriber.expiryDate,
        lastRenewedAt: body.lastRenewedAt !== undefined ? body.lastRenewedAt ? new Date(body.lastRenewedAt) : null : existingSubscriber.lastRenewedAt,
        serviceStatus: body.serviceStatus ?? existingSubscriber.serviceStatus,
      },
    });

    return NextResponse.json(subscriber);
  } catch (error) {
    console.error('Error updating subscriber:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء تحديث المشترك' },
      { status: 500 }
    );
  }
}

// DELETE - حذف مشترك
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    // التحقق من وجود المشترك
    const existingSubscriber = await db.subscriber.findUnique({
      where: { id: parseInt(id) },
      include: { invoices: true },
    });

    if (!existingSubscriber) {
      return NextResponse.json(
        { error: 'المشترك غير موجود' },
        { status: 404 }
      );
    }

    // حذف الفواتير المرتبطة أولاً
    await db.invoice.deleteMany({
      where: { subscriberId: parseInt(id) },
    });

    // حذف المشترك
    await db.subscriber.delete({
      where: { id: parseInt(id) },
    });

    return NextResponse.json({ message: 'تم حذف المشترك بنجاح' });
  } catch (error) {
    console.error('Error deleting subscriber:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء حذف المشترك' },
      { status: 500 }
    );
  }
}

// GET - جلب مشترك واحد
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const subscriber = await db.subscriber.findUnique({
      where: { id: parseInt(id) },
      include: {
        invoices: {
          orderBy: {
            month: 'desc',
          },
        },
      },
    });

    if (!subscriber) {
      return NextResponse.json(
        { error: 'المشترك غير موجود' },
        { status: 404 }
      );
    }

    return NextResponse.json(subscriber);
  } catch (error) {
    console.error('Error fetching subscriber:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب المشترك' },
      { status: 500 }
    );
  }
}
