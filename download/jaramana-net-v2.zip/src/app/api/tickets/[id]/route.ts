import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// PUT - تحديث التذكرة
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { status, response } = body;

    const updateData: Record<string, unknown> = {};
    
    if (status) updateData.status = status;
    if (response !== undefined) {
      updateData.response = response;
      updateData.respondedAt = new Date();
    }

    const ticket = await db.ticket.update({
      where: { id: parseInt(id) },
      data: updateData,
    });

    return NextResponse.json(ticket);
  } catch (error) {
    console.error('Error updating ticket:', error);
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

// DELETE - حذف التذكرة
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    await db.ticket.delete({
      where: { id: parseInt(id) },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting ticket:', error);
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
