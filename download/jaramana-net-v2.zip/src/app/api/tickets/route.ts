import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - جلب كل التذاكر
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');

    console.log('Fetching tickets...');
    
    const tickets = await db.ticket.findMany({
      where: status ? { status } : {},
      include: {
        subscriber: {
          select: { name: true, phone: true }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });

    console.log('Tickets fetched:', tickets.length);
    return NextResponse.json(tickets);
  } catch (error) {
    console.error('Error fetching tickets:', error);
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

// POST - إضافة تذكرة جديدة
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { subscriberId, name, phone, subject, message, priority } = body;

    if (!name || !phone || !subject || !message) {
      return NextResponse.json({ error: 'جميع البيانات مطلوبة' }, { status: 400 });
    }

    const ticket = await db.ticket.create({
      data: {
        subscriberId: subscriberId || null,
        name,
        phone,
        subject,
        message,
        priority: priority || 'normal',
      },
    });

    // إضافة إشعار
    await db.notification.create({
      data: {
        type: 'ticket_new',
        title: 'تذكرة جديدة',
        message: `تذكرة جديدة من ${name}: ${subject}`,
        relatedId: ticket.id,
      },
    });

    return NextResponse.json(ticket, { status: 201 });
  } catch (error) {
    console.error('Error creating ticket:', error);
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
