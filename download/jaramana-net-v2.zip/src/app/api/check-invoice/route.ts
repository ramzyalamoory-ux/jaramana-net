import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getPPPoEActiveUsers, formatBytes, parseUptime } from '@/lib/mikrotik';

// GET - البحث عن فاتورة مشترك بالاسم الثلاثي
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const name = searchParams.get('name');

    if (!name || name.trim().length < 3) {
      return NextResponse.json(
        { error: 'الرجاء إدخال الاسم الثلاثي كاملاً' },
        { status: 400 }
      );
    }

    // البحث بالاسم (يحتوي على)
    const subscriber = await db.subscriber.findFirst({
      where: {
        name: {
          contains: name.trim(),
        },
      },
      include: {
        invoices: {
          orderBy: {
            month: 'desc',
          },
        },
      },
    });

    if (!subscriber) {
      return NextResponse.json(
        { error: 'لا يوجد مشترك بهذا الاسم' },
        { status: 404 }
      );
    }

    // حساب إجمالي المبلغ المستحق
    const totalDue = subscriber.invoices
      .filter((invoice) => !invoice.isPaid)
      .reduce((sum, invoice) => sum + invoice.amount, 0);

    // جلب حالة الشبكة إذا كان لديه PPPoE
    type NetworkStatusType = {
      isOnline: boolean;
      ipAddress?: string;
      uptime?: string;
      uptimeFormatted?: string;
      bytesIn?: number;
      bytesOut?: number;
      bytesInFormatted?: string;
      bytesOutFormatted?: string;
      totalUsage?: string;
      lastSeen?: Date | null;
    } | null;
    
    let networkStatus: NetworkStatusType = null;
    if (subscriber.pppoeUser) {
      try {
        const device = await db.mikroTikDevice.findFirst({
          where: { isDefault: true, isActive: true }
        });

        if (device) {
          const config = {
            host: device.host,
            port: device.port,
            username: device.username,
            password: device.password,
          };

          const activeUsers = await getPPPoEActiveUsers(config);
          const activeUser = activeUsers.find(u => u.name === subscriber.pppoeUser);

          if (activeUser) {
            networkStatus = {
              isOnline: true,
              ipAddress: activeUser.address,
              uptime: activeUser.uptime,
              uptimeFormatted: formatUptimeArabic(activeUser.uptime),
              bytesIn: activeUser.bytesIn,
              bytesOut: activeUser.bytesOut,
              bytesInFormatted: formatBytes(activeUser.bytesIn),
              bytesOutFormatted: formatBytes(activeUser.bytesOut),
              totalUsage: formatBytes(activeUser.bytesIn + activeUser.bytesOut),
            };
          } else {
            networkStatus = {
              isOnline: false,
              lastSeen: subscriber.lastSeen,
            };
          }
        }
      } catch (error) {
        console.error('Error fetching network status:', error);
      }
    }

    return NextResponse.json({
      subscriber,
      totalDue,
      networkStatus,
    });
  } catch (error) {
    console.error('Error checking invoice:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء البحث عن الفاتورة' },
      { status: 500 }
    );
  }
}

// تنسيق مدة الاتصال بالعربية
function formatUptimeArabic(uptime: string): string {
  if (!uptime) return '0 دقيقة';
  
  const weeks = uptime.match(/(\d+)w/);
  const days = uptime.match(/(\d+)d/);
  const hours = uptime.match(/(\d+)h/);
  const minutes = uptime.match(/(\d+)m/);
  
  const parts: string[] = [];
  
  if (weeks) parts.push(`${weeks[1]} أسبوع`);
  if (days) parts.push(`${days[1]} يوم`);
  if (hours) parts.push(`${hours[1]} ساعة`);
  if (minutes) parts.push(`${minutes[1]} دقيقة`);
  
  return parts.join(' و ') || '0 دقيقة';
}
