import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - جلب الإعدادات
export async function GET() {
  try {
    const settings = await db.setting.findMany();
    const settingsMap: Record<string, string> = {};
    settings.forEach((s) => {
      settingsMap[s.key] = s.value;
    });

    // القيم الافتراضية
    const defaultSettings = {
      adminUsername: settingsMap.adminUsername || 'admin',
      adminPassword: settingsMap.adminPassword || 'admin12344321',
      adminPin: settingsMap.adminPin || '1234',
      companyName: settingsMap.companyName || 'جرمانا نت',
      companySlogan: settingsMap.companySlogan || 'اختيارك الأفضل - الإنترنت الأفضل في جرمانا',
      supportPhone1: settingsMap.supportPhone1 || '0992417870',
      supportPhone2: settingsMap.supportPhone2 || '0959128944',
      supportName1: settingsMap.supportName1 || 'Ghasan',
      supportName2: settingsMap.supportName2 || 'Ramzy',
    };

    return NextResponse.json(defaultSettings);
  } catch (error) {
    console.error('Error fetching settings:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب الإعدادات' },
      { status: 500 }
    );
  }
}

// POST - تحديث الإعدادات
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    for (const [key, value] of Object.entries(body)) {
      if (value !== undefined && value !== null) {
        await db.setting.upsert({
          where: { key },
          update: { value: String(value) },
          create: { key, value: String(value) },
        });
      }
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error updating settings:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء تحديث الإعدادات' },
      { status: 500 }
    );
  }
}
