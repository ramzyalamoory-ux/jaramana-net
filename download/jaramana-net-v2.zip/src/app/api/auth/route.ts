import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import crypto from 'crypto';

const MAX_ATTEMPTS = 5;
const BLOCK_DURATION_MINUTES = 15;
const SESSION_DURATION_HOURS = 2;

// Helper to get client IP
function getClientIP(request: NextRequest): string {
  const xff = request.headers.get('x-forwarded-for');
  if (xff) {
    return xff.split(',')[0].trim();
  }
  return 'unknown';
}

// Check if IP is blocked
async function isIPBlocked(ip: string): Promise<{ blocked: boolean; remainingMinutes: number }> {
  const recentAttempts = await db.loginAttempt.findMany({
    where: {
      ip,
      success: false,
      createdAt: {
        gte: new Date(Date.now() - BLOCK_DURATION_MINUTES * 60 * 1000)
      }
    },
    orderBy: { createdAt: 'desc' },
    take: MAX_ATTEMPTS
  });

  if (recentAttempts.length >= MAX_ATTEMPTS) {
    const lastAttempt = recentAttempts[0];
    const blockEndTime = new Date(lastAttempt.createdAt.getTime() + BLOCK_DURATION_MINUTES * 60 * 1000);
    const remainingMinutes = Math.ceil((blockEndTime.getTime() - Date.now()) / 60000);
    return { blocked: true, remainingMinutes: Math.max(0, remainingMinutes) };
  }

  return { blocked: false, remainingMinutes: 0 };
}

// Generate secure token
function generateToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

// POST - Login
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { username, password, pin } = body;
    const ip = getClientIP(request);
    const userAgent = request.headers.get('user-agent') || 'unknown';

    // Check if IP is blocked
    const { blocked, remainingMinutes } = await isIPBlocked(ip);
    if (blocked) {
      return NextResponse.json({
        error: `تم حظر هذا العنوان بسبب محاولات فاشلة كثيرة. حاول بعد ${remainingMinutes} دقيقة`,
        blocked: true,
        remainingMinutes
      }, { status: 429 });
    }

    // Get settings
    const settings = await db.setting.findMany();
    const settingsMap = Object.fromEntries(settings.map(s => [s.key, s.value]));

    const adminUsername = settingsMap.adminUsername || 'admin';
    const adminPassword = settingsMap.adminPassword || 'admin12344321';
    const adminPin = settingsMap.adminPin || '1234';

    // Verify credentials
    let success = false;
    let reason = '';

    if (username !== adminUsername) {
      reason = 'اسم المستخدم غير صحيح';
    } else if (password !== adminPassword) {
      reason = 'كلمة المرور غير صحيحة';
    } else if (pin && pin !== adminPin) {
      reason = 'رمز PIN غير صحيح';
    } else if (!pin) {
      reason = 'PIN مطلوب';
    } else {
      success = true;
    }

    // Log the attempt
    await db.loginAttempt.create({
      data: {
        ip,
        username,
        success,
        reason: success ? null : reason,
        userAgent
      }
    });

    if (!success) {
      // Count remaining attempts
      const failedAttempts = await db.loginAttempt.count({
        where: {
          ip,
          success: false,
          createdAt: {
            gte: new Date(Date.now() - BLOCK_DURATION_MINUTES * 60 * 1000)
          }
        }
      });

      return NextResponse.json({
        error: reason,
        remainingAttempts: MAX_ATTEMPTS - failedAttempts
      }, { status: 401 });
    }

    // Create session
    const token = generateToken();
    const expiresAt = new Date(Date.now() + SESSION_DURATION_HOURS * 60 * 60 * 1000);

    await db.adminSession.create({
      data: {
        token,
        ip,
        userAgent,
        expiresAt
      }
    });

    // Clean old sessions
    await db.adminSession.deleteMany({
      where: {
        expiresAt: { lt: new Date() }
      }
    });

    return NextResponse.json({
      success: true,
      token,
      expiresAt
    });

  } catch (error) {
    console.error('Auth error:', error);
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

// GET - Verify session
export async function GET(request: NextRequest) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '');
    const ip = getClientIP(request);

    if (!token) {
      return NextResponse.json({ valid: false }, { status: 401 });
    }

    const session = await db.adminSession.findUnique({
      where: { token }
    });

    if (!session) {
      return NextResponse.json({ valid: false }, { status: 401 });
    }

    if (new Date() > session.expiresAt) {
      await db.adminSession.delete({ where: { token } });
      return NextResponse.json({ valid: false, expired: true }, { status: 401 });
    }

    // Update last activity and extend session
    const newExpiresAt = new Date(Date.now() + SESSION_DURATION_HOURS * 60 * 60 * 1000);
    await db.adminSession.update({
      where: { token },
      data: {
        lastActivity: new Date(),
        expiresAt: newExpiresAt
      }
    });

    return NextResponse.json({
      valid: true,
      expiresAt: newExpiresAt
    });

  } catch (error) {
    console.error('Session verify error:', error);
    return NextResponse.json({ valid: false }, { status: 500 });
  }
}

// DELETE - Logout
export async function DELETE(request: NextRequest) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '');

    if (token) {
      await db.adminSession.deleteMany({
        where: { token }
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Logout error:', error);
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
