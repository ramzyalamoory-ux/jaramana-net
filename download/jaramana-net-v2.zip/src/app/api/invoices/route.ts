import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - جلب كل الفواتير مع إمكانية الفلترة
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const subscriberId = searchParams.get('subscriberId');
    const isPaid = searchParams.get('isPaid');
    const month = searchParams.get('month');

    const where: {
      subscriberId?: number;
      isPaid?: boolean;
      month?: string;
    } = {};

    if (subscriberId) {
      where.subscriberId = parseInt(subscriberId);
    }

    if (isPaid !== null && isPaid !== undefined) {
      where.isPaid = isPaid === 'true';
    }

    if (month) {
      where.month = month;
    }

    const invoices = await db.invoice.findMany({
      where,
      include: {
        subscriber: true,
      },
      orderBy: [
        { month: 'desc' },
        { createdAt: 'desc' },
      ],
    });

    return NextResponse.json(invoices);
  } catch (error) {
    console.error('Error fetching invoices:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب الفواتير' },
      { status: 500 }
    );
  }
}

// POST - إضافة فاتورة جديدة
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { subscriberId, month, amount, dueDate, notes } = body;

    // التحقق من البيانات المطلوبة
    if (!subscriberId || !month || amount === undefined) {
      return NextResponse.json(
        { error: 'جميع البيانات المطلوبة يجب إدخالها' },
        { status: 400 }
      );
    }

    // التحقق من وجود المشترك
    const subscriber = await db.subscriber.findUnique({
      where: { id: subscriberId },
    });

    if (!subscriber) {
      return NextResponse.json(
        { error: 'المشترك غير موجود' },
        { status: 404 }
      );
    }

    // التحقق من عدم وجود فاتورة لنفس الشهر
    const existingInvoice = await db.invoice.findUnique({
      where: {
        subscriberId_month: {
          subscriberId,
          month,
        },
      },
    });

    if (existingInvoice) {
      return NextResponse.json(
        { error: 'يوجد فاتورة لهذا الشهر بالفعل' },
        { status: 400 }
      );
    }

    const invoice = await db.invoice.create({
      data: {
        subscriberId,
        month,
        amount: parseFloat(amount),
        dueDate: dueDate ? new Date(dueDate) : new Date(),
        notes: notes || null,
      },
      include: {
        subscriber: true,
      },
    });

    return NextResponse.json(invoice, { status: 201 });
  } catch (error) {
    console.error('Error creating invoice:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء إضافة الفاتورة' },
      { status: 500 }
    );
  }
}
