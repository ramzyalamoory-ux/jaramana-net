import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// PUT - تحديث حالة الفاتورة (دفع/عدم دفع)
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { isPaid, paidAt, notes } = body;

    // التحقق من وجود الفاتورة
    const existingInvoice = await db.invoice.findUnique({
      where: { id: parseInt(id) },
    });

    if (!existingInvoice) {
      return NextResponse.json(
        { error: 'الفاتورة غير موجودة' },
        { status: 404 }
      );
    }

    const invoice = await db.invoice.update({
      where: { id: parseInt(id) },
      data: {
        isPaid: isPaid ?? existingInvoice.isPaid,
        paidAt: isPaid ? (paidAt ? new Date(paidAt) : new Date()) : null,
        notes: notes !== undefined ? notes : existingInvoice.notes,
      },
      include: {
        subscriber: true,
      },
    });

    return NextResponse.json(invoice);
  } catch (error) {
    console.error('Error updating invoice:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء تحديث الفاتورة' },
      { status: 500 }
    );
  }
}

// GET - جلب فاتورة واحدة
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const invoice = await db.invoice.findUnique({
      where: { id: parseInt(id) },
      include: {
        subscriber: true,
      },
    });

    if (!invoice) {
      return NextResponse.json(
        { error: 'الفاتورة غير موجودة' },
        { status: 404 }
      );
    }

    return NextResponse.json(invoice);
  } catch (error) {
    console.error('Error fetching invoice:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب الفاتورة' },
      { status: 500 }
    );
  }
}
